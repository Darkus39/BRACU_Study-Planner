#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════════
# build-installer.sh — BRACU Study Planner cross-platform installer builder
#
# Produces:
#   Linux  → StudyPlanner-2.0.0.rpm  (Fedora/RHEL) and/or .deb (Debian/Ubuntu)
#   macOS  → StudyPlanner-2.0.0.dmg
#
# Requirements:
#   - JDK 21+  (must include jpackage — bundled since JDK 14)
#   - Maven 3.8+
#   - Linux: rpm-build (for .rpm)  or  dpkg-deb (for .deb)
#   - macOS: Xcode Command Line Tools
#
# Usage:
#   chmod +x build-installer.sh
#   ./build-installer.sh
# ═══════════════════════════════════════════════════════════════════════════════

set -e  # Exit immediately on any error

APP_NAME="StudyPlanner"
APP_VERSION="2.0.0"
MAIN_CLASS="com.bracu.studyplanner.app.Launcher"
DESCRIPTION="BRACU Academic Management System"
VENDOR="BRACU Study Planner"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$SCRIPT_DIR"
TARGET_DIR="$PROJECT_DIR/target"
INSTALLER_DIR="$PROJECT_DIR/installer-output"

echo "═══════════════════════════════════════════════════════"
echo "  BRACU Study Planner — Installer Builder"
echo "  Platform: $(uname -s)"
echo "═══════════════════════════════════════════════════════"

# ── Step 1: Build the fat JAR ─────────────────────────────────────────────────
echo ""
echo "▶  Step 1/3 — Building fat JAR with Maven..."
cd "$PROJECT_DIR"
mvn clean package -q -DskipTests
echo "   ✓ JAR built: target/StudyPlannerFX-${APP_VERSION}.jar"

# ── Step 2: Prepare jpackage input ───────────────────────────────────────────
mkdir -p "$INSTALLER_DIR"
JAR_PATH="$TARGET_DIR/StudyPlannerFX-${APP_VERSION}.jar"

if [ ! -f "$JAR_PATH" ]; then
    echo "   ✗ ERROR: JAR not found at $JAR_PATH"
    exit 1
fi

# ── Step 3: Run jpackage ─────────────────────────────────────────────────────
echo ""
echo "▶  Step 2/3 — Running jpackage..."

OS="$(uname -s)"

JPACKAGE_COMMON_ARGS=(
    --input "$TARGET_DIR"
    --name "$APP_NAME"
    --main-jar "StudyPlannerFX-${APP_VERSION}.jar"
    --main-class "$MAIN_CLASS"
    --app-version "$APP_VERSION"
    --description "$DESCRIPTION"
    --vendor "$VENDOR"
    --dest "$INSTALLER_DIR"
    --java-options "--enable-preview"
    --java-options "-Dfile.encoding=UTF-8"
    --java-options "--add-opens=javafx.graphics/com.sun.javafx.application=ALL-UNNAMED"
    --java-options "--add-exports=javafx.base/com.sun.javafx=ALL-UNNAMED"
)

if [ "$OS" = "Linux" ]; then
    echo "   Platform: Linux"

    # Try .rpm first (Fedora/RHEL), then .deb (Debian/Ubuntu)
    if command -v rpmbuild &>/dev/null; then
        echo "   Building .rpm (rpmbuild found)..."
        jpackage "${JPACKAGE_COMMON_ARGS[@]}" \
            --type rpm \
            --linux-package-name "bracu-study-planner" \
            --linux-menu-group "Education" \
            --linux-shortcut
        echo "   ✓ RPM built in: $INSTALLER_DIR"
    fi

    if command -v dpkg-deb &>/dev/null || command -v fakeroot &>/dev/null; then
        echo "   Building .deb (dpkg found)..."
        jpackage "${JPACKAGE_COMMON_ARGS[@]}" \
            --type deb \
            --linux-package-name "bracu-study-planner" \
            --linux-menu-group "Education" \
            --linux-shortcut
        echo "   ✓ DEB built in: $INSTALLER_DIR"
    fi

    # Fallback: app-image (portable directory, no package manager needed)
    if ! command -v rpmbuild &>/dev/null && ! command -v dpkg-deb &>/dev/null; then
        echo "   No rpm/deb tools found. Building portable app-image..."
        jpackage "${JPACKAGE_COMMON_ARGS[@]}" --type app-image
        echo "   ✓ App image built in: $INSTALLER_DIR/$APP_NAME"
        echo "   → Run with: $INSTALLER_DIR/$APP_NAME/bin/$APP_NAME"
    fi

elif [ "$OS" = "Darwin" ]; then
    echo "   Platform: macOS"
    jpackage "${JPACKAGE_COMMON_ARGS[@]}" \
        --type dmg \
        --mac-package-name "$APP_NAME" \
        --mac-package-identifier "com.bracu.studyplanner"
    echo "   ✓ DMG built in: $INSTALLER_DIR"

else
    echo "   Unknown OS: $OS — building generic app-image"
    jpackage "${JPACKAGE_COMMON_ARGS[@]}" --type app-image
fi

# ── Done ─────────────────────────────────────────────────────────────────────
echo ""
echo "▶  Step 3/3 — Done!"
echo ""
echo "   Output directory: $INSTALLER_DIR"
ls -lh "$INSTALLER_DIR" 2>/dev/null || true
echo ""
echo "═══════════════════════════════════════════════════════"
echo "  Install notes:"
echo "  • Fedora:  sudo dnf install installer-output/*.rpm"
echo "  • Ubuntu:  sudo dpkg -i installer-output/*.deb"
echo "  • macOS:   open the .dmg and drag to Applications"
echo "  The installer bundles its own JRE — no Java needed on"
echo "  the target machine."
echo "═══════════════════════════════════════════════════════"
