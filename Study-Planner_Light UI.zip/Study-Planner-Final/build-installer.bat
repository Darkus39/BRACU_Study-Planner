@echo off
REM ═══════════════════════════════════════════════════════════════════════════
REM  build-installer.bat — BRACU Study Planner Windows installer builder
REM
REM  Produces:
REM    Windows → StudyPlanner-2.0.0.exe  (setup wizard via jpackage)
REM              StudyPlanner-2.0.0.msi  (MSI installer via jpackage, needs WiX)
REM
REM  Requirements:
REM    - JDK 21+  (must include jpackage, bundled since JDK 14)
REM    - Maven 3.8+ on PATH
REM    - WiX Toolset 3.x on PATH (for .msi only — https://wixtoolset.org)
REM
REM  Usage:
REM    Double-click  build-installer.bat
REM    OR from PowerShell:  .\build-installer.bat
REM ═══════════════════════════════════════════════════════════════════════════

setlocal enabledelayedexpansion

:: ── Self-elevate to Administrator ─────────────────────────────────────────
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrator privileges...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

set APP_NAME=StudyPlanner
set APP_VERSION=2.0.0
set MAIN_CLASS=com.bracu.studyplanner.app.Launcher
set DESCRIPTION=BRACU Academic Management System
set VENDOR=BRACU Study Planner

set SCRIPT_DIR=%~dp0
set PROJECT_DIR=%SCRIPT_DIR%
set TARGET_DIR=%PROJECT_DIR%target
set INSTALLER_DIR=%PROJECT_DIR%installer-output

echo.
echo ===================================================
echo   BRACU Study Planner - Windows Installer Builder
echo ===================================================
echo.

:: ── Check for spaces or brackets in path ──────────────────────────────────
echo %PROJECT_DIR% | findstr /C:"(" /C:")" /C:" " >nul 2>&1
if %errorlevel% equ 0 (
    echo [ERROR] The folder path contains spaces or brackets:
    echo %PROJECT_DIR%
    echo.
    echo jpackage cannot handle spaces or brackets in paths.
    echo Please move the project to a clean path like:
    echo   C:\StudyPlannerFX\
    echo.
    pause
    exit /b 1
)

:: ── Check Java ────────────────────────────────────────────────────────────
echo Checking Java...
java -version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Java not found. Please install JDK 21+:
    echo   winget install --id Microsoft.OpenJDK.21
    echo   or: https://adoptium.net
    pause
    exit /b 1
)
where jpackage >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] jpackage not found. Make sure you have JDK 21+ ^(not just JRE^).
    pause
    exit /b 1
)
echo [OK] Java and jpackage found.

:: ── Check Maven ───────────────────────────────────────────────────────────
echo Checking Maven...
where mvn >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Maven not found. Install it first:
    echo   winget install --id Apache.Maven
    echo   or run install-windows.bat which handles this automatically.
    pause
    exit /b 1
)
echo [OK] Maven found.

:: ── Step 1: Build fat JAR ─────────────────────────────────────────────────
echo.
echo [1/3] Building fat JAR with Maven...
cd /d "%PROJECT_DIR%"
call mvn clean package -q -DskipTests
if errorlevel 1 (
    echo [ERROR] Maven build failed.
    echo Run:  mvn clean package -e   for detailed output.
    pause
    exit /b 1
)
echo       Done: target\StudyPlannerFX-%APP_VERSION%.jar

:: ── Step 2: Check JAR exists ──────────────────────────────────────────────
set JAR_PATH=%TARGET_DIR%\StudyPlannerFX-%APP_VERSION%.jar
if not exist "%JAR_PATH%" (
    echo [ERROR] JAR not found at %JAR_PATH%
    pause
    exit /b 1
)

:: ── Step 3: Create output directory ──────────────────────────────────────
if not exist "%INSTALLER_DIR%" mkdir "%INSTALLER_DIR%"

:: ── Step 4: Build .exe installer ─────────────────────────────────────────
echo.
echo [2/3] Building .exe installer with jpackage...

jpackage ^
    --input "%TARGET_DIR%" ^
    --name "%APP_NAME%" ^
    --main-jar "StudyPlannerFX-%APP_VERSION%.jar" ^
    --main-class "%MAIN_CLASS%" ^
    --app-version "%APP_VERSION%" ^
    --description "%DESCRIPTION%" ^
    --vendor "%VENDOR%" ^
    --dest "%INSTALLER_DIR%" ^
    --type exe ^
    --win-dir-chooser ^
    --win-menu ^
    --win-menu-group "BRACU" ^
    --win-shortcut ^
    --win-shortcut-prompt ^
    --java-options "-Dfile.encoding=UTF-8" ^
    --java-options "--add-opens=javafx.graphics/com.sun.javafx.application=ALL-UNNAMED"

if errorlevel 1 (
    echo WARNING: .exe build failed. Trying portable app-image fallback...
    jpackage ^
        --input "%TARGET_DIR%" ^
        --name "%APP_NAME%" ^
        --main-jar "StudyPlannerFX-%APP_VERSION%.jar" ^
        --main-class "%MAIN_CLASS%" ^
        --app-version "%APP_VERSION%" ^
        --dest "%INSTALLER_DIR%" ^
        --type app-image ^
        --java-options "-Dfile.encoding=UTF-8"
    if errorlevel 1 (
        echo [ERROR] app-image also failed. Check jpackage output above.
        pause
        exit /b 1
    )
    echo       Portable app-image built.
    echo       Run: installer-output\%APP_NAME%\%APP_NAME%.exe
    goto :done
)

echo       .exe installer built.

:: ── Step 5: Try .msi as well (requires WiX) ──────────────────────────────
where candle >nul 2>&1
if not errorlevel 1 (
    echo.
    echo       WiX found - also building .msi...
    jpackage ^
        --input "%TARGET_DIR%" ^
        --name "%APP_NAME%" ^
        --main-jar "StudyPlannerFX-%APP_VERSION%.jar" ^
        --main-class "%MAIN_CLASS%" ^
        --app-version "%APP_VERSION%" ^
        --vendor "%VENDOR%" ^
        --dest "%INSTALLER_DIR%" ^
        --type msi ^
        --win-dir-chooser ^
        --win-menu ^
        --win-menu-group "BRACU" ^
        --win-shortcut ^
        --java-options "-Dfile.encoding=UTF-8"
    if not errorlevel 1 (
        echo       .msi installer built.
    ) else (
        echo       .msi build failed ^(WiX error^) — .exe is still available.
    )
)

:done
echo.
echo [3/3] Done!
echo.
echo ===================================================
echo   Output: %INSTALLER_DIR%
echo.
echo   To install:
echo     .exe  - Double-click the setup wizard
echo     .msi  - Double-click or deploy via Group Policy
echo.
echo   The installer bundles its own JRE.
echo   No Java installation needed on target machines.
echo ===================================================
echo.
pause
