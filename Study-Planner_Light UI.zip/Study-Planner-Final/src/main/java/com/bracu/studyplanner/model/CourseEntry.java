package com.bracu.studyplanner.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Represents a single course (theory or lab) in a student's semester plan.
 * Used as row data in the JavaFX TableView.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CourseEntry {

    private String  code;
    private String  name;
    private int     credits;
    private int     difficultyWeight; // 1 = Easy, 2 = Medium, 3 = Hard
    private boolean lab;              // true = auto-added lab companion
    private boolean retake;           // true = student is repeating/retaking this course

    // Daily study tracking — reset automatically when the date changes
    private int    studiedMinutesToday = 0;
    private String lastStudyDate       = "";  // ISO date: "2025-04-01"

    // ── Study tracking helpers ───────────────────────────────────────────────

    /**
     * Adds minutes to today's log.
     * Auto-resets the counter if the stored date differs from today's date.
     */
    public void logStudyMinutes(int minutes) {
        String today = java.time.LocalDate.now(java.time.ZoneId.of("Asia/Dhaka")).toString();
        if (!today.equals(lastStudyDate)) {
            studiedMinutesToday = 0;
            lastStudyDate       = today;
        }
        studiedMinutesToday = Math.max(0, studiedMinutesToday + minutes);
    }

    /**
     * Resets the daily counter if the stored date is not today.
     * Called on app startup / load so stale data doesn't linger.
     */
    public void resetIfNewDay() {
        String today = java.time.LocalDate.now(java.time.ZoneId.of("Asia/Dhaka")).toString();
        if (!today.equals(lastStudyDate)) {
            studiedMinutesToday = 0;
            lastStudyDate       = today;
        }
    }

    // ── Display helpers ──────────────────────────────────────────────────────

    /** Human-readable difficulty label for the UI. */
    public String getDifficultyLabel() {
        if (lab) return "Lab";
        return switch (difficultyWeight) {
            case 1  -> "Easy";
            case 2  -> "Medium";
            case 3  -> "Hard";
            default -> "—";
        };
    }

    /** Star-icon difficulty for the table column. */
    public String getDifficultyStars() {
        if (lab) return "Lab";
        return "★".repeat(difficultyWeight) + "☆".repeat(Math.max(0, 3 - difficultyWeight));
    }
}
