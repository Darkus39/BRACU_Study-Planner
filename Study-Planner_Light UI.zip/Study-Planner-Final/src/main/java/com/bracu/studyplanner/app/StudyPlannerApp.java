package com.bracu.studyplanner.app;

import com.bracu.studyplanner.service.StudentService;
import com.bracu.studyplanner.view.screens.MainScreen;
import com.bracu.studyplanner.view.screens.SetupScreen;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext;

import java.util.Objects;

/**
 * JavaFX Application root.
 *
 * Boot sequence:
 *  1. init()  → start Spring Boot context (runs on JavaFX init thread)
 *  2. start() → build Scene, decide Setup vs Main based on profile existence
 *  3. stop()  → close Spring context cleanly on window close
 *
 * Spring DI is fully available from step 1 onward; JavaFX beans
 * are retrieved via springContext.getBean(…) and passed as constructor args.
 */
public class StudyPlannerApp extends Application {

    private ConfigurableApplicationContext springContext;

    // ── JavaFX lifecycle ─────────────────────────────────────────────────────

    @Override
    public void init() {
        // Spring Boot starts here — NOT on the FX Application Thread.
        // That is correct: Spring context bootstrap is intentionally off-thread.
        springContext = SpringApplication.run(SpringConfig.class, getParameters().getRaw().toArray(new String[0]));
    }

    @Override
    public void start(Stage primaryStage) {
        StudentService studentService = springContext.getBean(StudentService.class);

        // Root container — swap children between Setup and Main
        javafx.scene.layout.StackPane root = new javafx.scene.layout.StackPane();

        Scene scene = new Scene(root, 1180, 760);
        scene.getStylesheets().add(
            Objects.requireNonNull(
                getClass().getResource("/com/bracu/studyplanner/css/app.css")
            ).toExternalForm()
        );

        // ── Route: no profile → setup wizard; profile exists → main dashboard ──
        Runnable showMain = () -> Platform.runLater(() -> {
            MainScreen mainScreen = new MainScreen(studentService, () ->
                Platform.runLater(() -> showSetup(root, studentService, scene, primaryStage))
            );
            root.getChildren().setAll(mainScreen);
        });

        if (studentService.hasProfile()) {
            root.getChildren().add(new MainScreen(studentService,
                () -> Platform.runLater(() -> showSetup(root, studentService, scene, primaryStage))
            ));
        } else {
            root.getChildren().add(new SetupScreen(studentService, showMain));
        }

        // ── Stage config ──────────────────────────────────────────────────────
        primaryStage.setTitle("BRACU Study Planner");
        primaryStage.setScene(scene);
        primaryStage.setMinWidth(900);
        primaryStage.setMinHeight(600);
        primaryStage.setWidth(1180);
        primaryStage.setHeight(760);

        // App icon (loaded gracefully — missing icon won't crash)
        try {
            primaryStage.getIcons().add(new Image(
                Objects.requireNonNull(getClass().getResourceAsStream(
                    "/com/bracu/studyplanner/css/icon.png"))));
        } catch (Exception ignored) {}

        primaryStage.centerOnScreen();
        primaryStage.show();
    }

    @Override
    public void stop() {
        springContext.close();
        Platform.exit();
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private void showSetup(javafx.scene.layout.StackPane root,
                           StudentService studentService,
                           Scene scene,
                           Stage stage) {
        // Reset the service state for a fresh profile
        studentService.clearProfile();
        Runnable showMain = () -> Platform.runLater(() -> {
            MainScreen ms = new MainScreen(studentService,
                () -> Platform.runLater(() -> showSetup(root, studentService, scene, stage))
            );
            root.getChildren().setAll(ms);
        });
        root.getChildren().setAll(new SetupScreen(studentService, showMain));
    }

    // ── Entry point (called by Launcher) ─────────────────────────────────────

    public static void main(String[] args) {
        launch(args);
    }
}
