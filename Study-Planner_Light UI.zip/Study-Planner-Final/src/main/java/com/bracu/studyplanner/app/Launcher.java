package com.bracu.studyplanner.app;

/**
 * Launcher — the true entry point for both the fat-JAR and jpackage installer.
 *
 * WHY a separate Launcher class?
 *   JavaFX 11+ requires the Application class to be on the module path, but
 *   Spring Boot's fat-JAR loader uses a custom ClassLoader that confuses the
 *   JavaFX launcher when main() lives directly in an Application subclass.
 *   Delegating through a plain class avoids that conflict on all platforms.
 */
public class Launcher {

    public static void main(String[] args) {
        // Delegate to JavaFX's launch mechanism via StudyPlannerApp
        StudyPlannerApp.main(args);
    }
}
