package com.bracu.studyplanner.service;

import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * Spring-managed repository for the static BRACU course database.
 *
 * Loaded once on startup via @PostConstruct and held in memory.
 * Thread-safe after initialization (read-only map, no mutations).
 *
 * File format (courseList):
 *   CODE:Course Name:difficultyWeight
 *   e.g.  CSE221:Algorithms:3
 */
@Component
public class CourseRepository {

    // key = UPPERCASE course code, value = [code, name, weight]
    private final Map<String, String[]> cache = new HashMap<>();

    @PostConstruct
    public void load() {
        InputStream is = getClass().getResourceAsStream("/com/bracu/studyplanner/data/courseList");
        if (is == null) {
            System.err.println("[CourseRepository] WARNING: courseList resource not found.");
            return;
        }
        try (Scanner sc = new Scanner(is)) {
            while (sc.hasNextLine()) {
                String line = sc.nextLine().trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                String[] parts = line.split("\\s*[:;]\\s*");
                if (parts.length >= 2) {
                    cache.put(parts[0].trim().toUpperCase(), parts);
                }
            }
        }
        System.out.printf("[CourseRepository] Loaded %d courses.%n", cache.size());
    }

    // ── Public API ───────────────────────────────────────────────────────────

    public boolean exists(String code) {
        return cache.containsKey(upper(code));
    }

    public String getName(String code) {
        String[] parts = cache.get(upper(code));
        return (parts != null && parts.length >= 2) ? parts[1].trim() : "Unknown";
    }

    /**
     * Returns the credit value.
     * Labs (ending in L, or 3rd digit == '0') → 0 credits in plan display.
     * Theory                                  → 3 credits.
     */
    public int getCredits(String code) {
        String u = upper(code);
        if (u.endsWith("L") || (u.length() >= 4 && u.charAt(3) == '0')) return 0;
        return 3;
    }

    /** Returns difficulty weight 1–3, defaulting to 2 if not set. */
    public int getWeight(String code) {
        String[] parts = cache.get(upper(code));
        if (parts != null && parts.length >= 3) {
            try { return Integer.parseInt(parts[2].trim()); }
            catch (NumberFormatException ignored) {}
        }
        return 2;
    }

    private String upper(String code) {
        return code == null ? "" : code.toUpperCase().trim();
    }
}
