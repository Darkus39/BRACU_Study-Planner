package com.bracu.studyplanner.view.screens.tabs;

import com.bracu.studyplanner.model.CourseEntry;
import com.bracu.studyplanner.service.ScheduleService;
import com.bracu.studyplanner.service.StudentService;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.List;

/**
 * Study Schedule tab — shows weighted daily time allocation and topic roadmap.
 * Regenerates automatically whenever the planned courses list changes.
 */
public class ScheduleTab extends ScrollPane {

    private final StudentService  studentService;
    private final ScheduleService scheduleService;
    private final VBox            scheduleBox;
    private final VBox            roadmapBox;

    public ScheduleTab(StudentService studentService) {
        this.studentService  = studentService;
        this.scheduleService = new ScheduleService(); // lightweight, no Spring needed here

        setFitToWidth(true);
        setHbarPolicy(ScrollBarPolicy.NEVER);
        getStyleClass().add("tab-scroll");

        VBox root = new VBox(28);
        root.getStyleClass().add("tab-root");
        root.setPadding(new Insets(36, 40, 36, 40));

        Label title    = new Label("STUDY SCHEDULE");
        Label subtitle = new Label("Weighted daily plan · Topic roadmap");
        title.getStyleClass().add("page-title");
        subtitle.getStyleClass().add("page-subtitle");

        // ── Daily schedule panel ──────────────────────────────────────────────
        VBox schedPanel = new VBox(14);
        schedPanel.getStyleClass().add("panel");
        schedPanel.getChildren().add(panelTitle("DAILY TIME ALLOCATION"));
        scheduleBox = new VBox(10);
        schedPanel.getChildren().add(scheduleBox);

        // ── Roadmap panel ─────────────────────────────────────────────────────
        VBox roadPanel = new VBox(14);
        roadPanel.getStyleClass().add("panel");
        roadPanel.getChildren().add(panelTitle("TOPIC ROADMAP"));
        roadmapBox = new VBox(14);
        roadPanel.getChildren().add(roadmapBox);

        root.getChildren().addAll(new VBox(4, title, subtitle), schedPanel, roadPanel);
        setContent(root);

        // Rebuild whenever courses change
        studentService.plannedCoursesProperty().addListener(
            (javafx.collections.ListChangeListener<com.bracu.studyplanner.model.CourseEntry>) c -> rebuild());
        rebuild();
    }

    private void rebuild() {
        double hours   = studentService.studyHoursProperty().get();
        var    courses = List.copyOf(studentService.plannedCoursesProperty());

        List<ScheduleService.ScheduleEntry> schedule = scheduleService.generateSchedule(courses, hours);
        List<ScheduleService.RoadmapEntry>  roadmap  = scheduleService.generateRoadmap(courses);

        // ── Schedule cards ────────────────────────────────────────────────────
        scheduleBox.getChildren().clear();
        if (schedule.isEmpty()) {
            scheduleBox.getChildren().add(emptyLabel("Add courses in the Course Manager to generate a schedule."));
        } else {
            for (ScheduleService.ScheduleEntry entry : schedule) {
                scheduleBox.getChildren().add(buildScheduleRow(entry, hours));
            }
        }

        // ── Roadmap cards ─────────────────────────────────────────────────────
        roadmapBox.getChildren().clear();
        if (roadmap.isEmpty()) {
            roadmapBox.getChildren().add(emptyLabel("No courses added yet."));
        } else {
            for (ScheduleService.RoadmapEntry entry : roadmap) {
                roadmapBox.getChildren().add(buildRoadmapCard(entry));
            }
        }
    }

    private HBox buildScheduleRow(ScheduleService.ScheduleEntry entry, double totalHours) {
        // Find the live CourseEntry for this row so we can read studiedMinutesToday
        CourseEntry live = studentService.plannedCoursesProperty().stream()
            .filter(e -> e.getCode().equalsIgnoreCase(entry.code()))
            .findFirst().orElse(null);

        int studiedMinutes = live != null ? live.getStudiedMinutesToday() : 0;
        double progress    = Math.min(1.0, studiedMinutes / (double) entry.minutes());

        HBox row = new HBox(12);
        row.setAlignment(Pos.CENTER_LEFT);
        row.getStyleClass().add("schedule-row");

        // Course code badge
        Label codeLbl = new Label(entry.code());
        codeLbl.getStyleClass().add("schedule-code");
        codeLbl.setMinWidth(90);

        // Course name
        Label nameLbl = new Label(entry.name());
        nameLbl.getStyleClass().add("schedule-name");
        HBox.setHgrow(nameLbl, Priority.ALWAYS);

        // Custom bar — plain StackPane so we own rendering entirely
        javafx.scene.layout.StackPane barTrack = new javafx.scene.layout.StackPane();
        barTrack.setPrefSize(130, 7);
        barTrack.setMaxHeight(7);
        barTrack.setStyle("-fx-background-color: #eef0f8; -fx-background-radius: 3;");

        javafx.scene.layout.Region barFill = new javafx.scene.layout.Region();
        barFill.setPrefHeight(7);
        barFill.setMaxHeight(7);
        barFill.setPrefWidth(130 * progress);
        barFill.setMinWidth(progress > 0 ? 4 : 0);
        String fillColor = progress >= 1.0 ? "#22c55e" : "linear-gradient(to right, #a5b4fc, #3b6cf7)";
        barFill.setStyle("-fx-background-color: " + fillColor + "; -fx-background-radius: 3;");
        javafx.scene.layout.StackPane.setAlignment(barFill, javafx.geometry.Pos.CENTER_LEFT);
        barTrack.getChildren().add(barFill);

        // Time label: "45m / 1h 30m"
        String allocStr   = formatMinutes(entry.minutes());
        String studiedStr = formatMinutes(studiedMinutes);
        Label timeLbl = new Label(studiedStr + " / " + allocStr);
        timeLbl.getStyleClass().add("schedule-time");
        timeLbl.setMinWidth(100);

        // Difficulty chip
        Label diff = new Label(entry.diffLabel());
        diff.getStyleClass().add(switch (entry.weight()) {
            case 1  -> "chip-green";
            case 3  -> "chip-red";
            default -> "chip-yellow";
        });
        diff.setMinWidth(60);

        // "+ Log" button — disabled once allocation is fully met
        Button logBtn = new Button("+ Log");
        logBtn.getStyleClass().add("log-btn");
        logBtn.setDisable(studiedMinutes >= entry.minutes());
        logBtn.setOnAction(e -> showLogDialog(entry.code(), entry.name(), entry.minutes(), studiedMinutes));

        row.getChildren().addAll(codeLbl, nameLbl, barTrack, timeLbl, diff, logBtn);
        return row;
    }

    /** Opens a simple dialog asking how many minutes the student studied. */
    private void showLogDialog(String code, String name, int allocatedMinutes, int alreadyStudied) {
        int remaining = allocatedMinutes - alreadyStudied;
        if (remaining <= 0) return;

        Dialog<Integer> dialog = new Dialog<>();
        dialog.setTitle("Log Study Time");
        dialog.setHeaderText(code + " — " + name);

        ButtonType logType = new ButtonType("Log", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(logType, ButtonType.CANCEL);

        // Spinner max = exact remaining minutes so you can never exceed allocation
        int initialValue = Math.min(30, remaining);
        Spinner<Integer> spinner = new Spinner<>(5, remaining, initialValue, 5);
        spinner.setEditable(true);
        spinner.setPrefWidth(110);

        // Clamp any typed value on focus loss
        spinner.getEditor().focusedProperty().addListener((obs, wasFocused, isNowFocused) -> {
            if (!isNowFocused) {
                try {
                    int typed   = Integer.parseInt(spinner.getEditor().getText().trim());
                    int clamped = Math.max(5, Math.min(remaining, typed));
                    spinner.getValueFactory().setValue(clamped);
                    spinner.getEditor().setText(String.valueOf(clamped));
                } catch (NumberFormatException ex) {
                    spinner.getEditor().setText(String.valueOf(spinner.getValue()));
                }
            }
        });

        Label hint = new Label("Remaining: " + formatMinutes(remaining) + "  ·  Allocated: " + formatMinutes(allocatedMinutes));
        hint.getStyleClass().add("panel-subtitle");

        VBox content = new VBox(10,
            new Label("Minutes studied:"),
            spinner,
            hint
        );
        content.setPadding(new Insets(12, 16, 4, 16));
        dialog.getDialogPane().setContent(content);

        dialog.setResultConverter(btn -> btn == logType ? spinner.getValue() : null);

        dialog.showAndWait().ifPresent(minutes -> {
            studentService.logStudyTime(code, minutes);
            rebuild();
        });
    }

    private String formatMinutes(int totalMinutes) {
        int h = totalMinutes / 60;
        int m = totalMinutes % 60;
        if (h > 0 && m > 0) return h + "h " + m + "m";
        if (h > 0)           return h + "h";
        return m + "m";
    }

    private VBox buildRoadmapCard(ScheduleService.RoadmapEntry entry) {
        VBox card = new VBox(10);
        card.getStyleClass().add("roadmap-card");

        HBox header = new HBox(10);
        header.setAlignment(Pos.CENTER_LEFT);
        Label code = new Label(entry.code());
        code.getStyleClass().add("roadmap-code");
        Label name = new Label(entry.name());
        name.getStyleClass().add("roadmap-name");
        header.getChildren().addAll(code, name);

        FlowPane topics = new FlowPane(8, 6);
        for (String topic : entry.topics()) {
            Label chip = new Label(topic);
            chip.getStyleClass().add("chip-outline");
            topics.getChildren().add(chip);
        }

        card.getChildren().addAll(header, topics);
        return card;
    }

    private Label emptyLabel(String text) {
        Label l = new Label(text);
        l.getStyleClass().add("panel-subtitle");
        return l;
    }

    private Label panelTitle(String text) {
        Label l = new Label("▪  " + text);
        l.getStyleClass().add("panel-title");
        return l;
    }
}
