package com.bracu.studyplanner.service;

import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Spring service for all CGPA computation.
 *
 * Formulae:
 *   maxCgpa = (currentCgpa * completed + 4.0 * theory) / (completed + theory)
 *   minCgpa = (currentCgpa * completed)                / (completed + theory)
 *   newCumulative = (currentCgpa * completedBefore + semGpa * theory) / (completedBefore + theory)
 */
@Service
public class CgpaService {

    /**
     * Maximum achievable CGPA if student scores 4.0 in all courses this semester.
     */
    public double maxAchievable(double currentCgpa, int completed, int theoryCount) {
        int total = completed + theoryCount;
        if (total == 0) return currentCgpa;
        return round((currentCgpa * completed + 4.0 * theoryCount) / total);
    }

    /**
     * Minimum CGPA if student fails all courses this semester (0.0 in each).
     */
    public double minIfAllFail(double currentCgpa, int completed, int theoryCount) {
        int total = completed + theoryCount;
        if (total == 0) return currentCgpa;
        return round((currentCgpa * completed) / total);
    }

    /**
     * Calculates the new cumulative CGPA after the semester is finalized.
     *
     * @param currentCgpa     CGPA before this semester
     * @param completedBefore credit courses done before this semester
     * @param semesterGpa     GPA the student achieved this semester
     * @param theoryCount     theory courses taken this semester
     */
    public double finalizeCgpa(double currentCgpa,
                               int    completedBefore,
                               double semesterGpa,
                               int    theoryCount) {
        int newTotal = completedBefore + theoryCount;
        if (newTotal == 0) return currentCgpa;
        return round((currentCgpa * completedBefore + semesterGpa * theoryCount) / newTotal);
    }

    private double round(double value) {
        return new BigDecimal(value)
            .setScale(2, RoundingMode.HALF_UP)
            .doubleValue();
    }
}
