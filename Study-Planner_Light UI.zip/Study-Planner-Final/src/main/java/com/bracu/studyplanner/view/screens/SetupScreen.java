package com.bracu.studyplanner.view.screens;

import com.bracu.studyplanner.service.StudentService;
import com.bracu.studyplanner.view.components.FormField;
import com.bracu.studyplanner.view.components.StatusBadge;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Text;

/**
 * First-launch profile setup wizard.
 *
 * BUG FIX (Fedora 43 freeze):
 *   The original code called onComplete.run() synchronously inside the button
 *   handler. On some Linux/GTK builds, swapping the scene root from inside a
 *   control event handler causes a deadlock in the JavaFX pulse scheduler.
 *   Fix: wrap onComplete.run() in Platform.runLater() so the scene graph swap
 *   happens on the NEXT pulse, after the current event has fully dispatched.
 */
public class SetupScreen extends StackPane {

    public SetupScreen(StudentService service, Runnable onComplete) {
        setStyle("-fx-background-color: #070a0f;");

        // ── Background grid dots (CSS radial-gradient via inline style) ───────
        Region bgDots = new Region();
        bgDots.setStyle(
            "-fx-background-color: radial-gradient(radius 1px, rgba(59,130,246,0.25) 0%, transparent 100%);" +
            "-fx-background-size: 28px 28px;");
        bgDots.setMouseTransparent(true);
        getChildren().add(bgDots);

        // ── Card ─────────────────────────────────────────────────────────────
        VBox card = new VBox(20);
        card.getStyleClass().add("setup-card");
        card.setMaxWidth(460);
        card.setAlignment(Pos.TOP_LEFT);

        // Header
        Label appName = new Label("BRACU STUDY PLANNER");
        appName.getStyleClass().add("setup-app-name");

        Label tagline = new Label("Academic management system — v2.0");
        tagline.getStyleClass().add("setup-tagline");

        Separator sep = new Separator();
        sep.getStyleClass().add("card-sep");

        Label heading = new Label("CREATE STUDENT PROFILE");
        heading.getStyleClass().add("section-heading");

        // Form fields
        FormField nameField  = new FormField("FULL NAME",                 "e.g.  Arif Hossain");
        FormField idField    = new FormField("STUDENT ID",                "e.g.  21301234");
        FormField cgpaField  = new FormField("CURRENT CGPA",             "0.00 – 4.00");
        FormField countField = new FormField("CREDIT COURSES COMPLETED", "e.g.  12");

        TextField nameInput  = nameField.getInput();
        TextField idInput    = idField.getInput();
        TextField cgpaInput  = cgpaField.getInput();
        TextField countInput = countField.getInput();

        // Error status
        StatusBadge errorBadge = new StatusBadge();

        // Submit button
        Button createBtn = new Button("INITIALIZE PROFILE  →");
        createBtn.getStyleClass().add("btn-primary");
        createBtn.setMaxWidth(Double.MAX_VALUE);

        createBtn.setOnAction(e -> {
            errorBadge.hide();

            String name     = nameInput.getText().trim();
            String id       = idInput.getText().trim();
            String cgpaStr  = cgpaInput.getText().trim().replace(",", ".");
            String countStr = countInput.getText().trim();

            // ── Local pre-validation ──────────────────────────────────────
            if (!name.matches("[a-zA-Z .'-]+")) {
                errorBadge.show("⚠  Name must contain only letters and spaces.");
                return;
            }
            double cgpaVal;
            try   { cgpaVal = Double.parseDouble(cgpaStr); }
            catch (NumberFormatException ex) {
                errorBadge.show("⚠  CGPA must be a number  (e.g.  3.45)");
                return;
            }
            int countVal;
            try   { countVal = Integer.parseInt(countStr); }
            catch (NumberFormatException ex) {
                errorBadge.show("⚠  Completed courses must be a whole number.");
                return;
            }

            // ── Delegate to service (full validation + persistence) ────────
            String serviceError = service.createProfile(name, id, cgpaVal, countVal);
            if (serviceError != null) {
                errorBadge.show("⚠  " + serviceError);
                return;
            }

            // ── BUG FIX: defer scene-graph swap to next FX pulse ──────────
            //    Without Platform.runLater, swapping the root node from inside
            //    a button action handler causes a freeze on Linux/GTK builds.
            Platform.runLater(onComplete);
        });

        // Allow Enter in last field to submit
        countInput.setOnAction(e -> createBtn.fire());
        cgpaInput.setOnAction(e -> countInput.requestFocus());
        idInput.setOnAction(e -> cgpaInput.requestFocus());
        nameInput.setOnAction(e -> idInput.requestFocus());

        card.getChildren().addAll(
            appName, tagline, sep, heading,
            nameField, idField, cgpaField, countField,
            errorBadge, createBtn
        );

        getChildren().add(card);
        StackPane.setAlignment(card, Pos.CENTER);
    }
}
