package com.bracu.studyplanner.view.screens.tabs;

import com.bracu.studyplanner.service.StudentService;
import com.bracu.studyplanner.view.components.StatCard;
import javafx.beans.binding.Bindings;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.text.DecimalFormat;

/**
 * Dashboard tab — student overview, live CGPA forecast, planned course count.
 * All labels bind directly to StudentService observable properties.
 */
public class DashboardTab extends ScrollPane {

    private static final DecimalFormat DF = new DecimalFormat("0.00");

    public DashboardTab(StudentService service) {
        setFitToWidth(true);
        setHbarPolicy(ScrollBarPolicy.NEVER);
        getStyleClass().add("tab-scroll");

        VBox root = new VBox(28);
        root.getStyleClass().add("tab-root");
        root.setPadding(new Insets(36, 40, 36, 40));

        // ── Page header ───────────────────────────────────────────────────────
        VBox header = pageHeader("Dashboard", "Academic overview");

        // ── Stat cards row ────────────────────────────────────────────────────
        HBox cardRow = new HBox(16);
        cardRow.setFillHeight(true);

        StatCard cgpaCard  = new StatCard("CURRENT CGPA", StatCard.Variant.ACCENT);
        StatCard semCard   = new StatCard("CURRENT SEMESTER", StatCard.Variant.DEFAULT);
        StatCard numCard   = new StatCard("SEMESTER NUMBER", StatCard.Variant.DEFAULT);
        StatCard compCard  = new StatCard("COURSES COMPLETED", StatCard.Variant.DEFAULT);

        cgpaCard.valueLabelProperty().textProperty().bind(
            Bindings.createStringBinding(() -> DF.format(service.cgpaProperty().get()), service.cgpaProperty()));
        semCard.valueLabelProperty().textProperty().bind(service.currentSemesterProperty());
        numCard.valueLabelProperty().textProperty().bind(service.semesterCountProperty());
        compCard.valueLabelProperty().textProperty().bind(
            Bindings.createStringBinding(() -> String.valueOf(service.completedCoursesProperty().get()), service.completedCoursesProperty()));

        for (javafx.scene.Node n : new javafx.scene.Node[]{cgpaCard, semCard, numCard, compCard}) {
            HBox.setHgrow(n, Priority.ALWAYS);
            cardRow.getChildren().add(n);
        }

        // ── CGPA Forecast panel ───────────────────────────────────────────────
        VBox forecastPanel = new VBox(16);
        forecastPanel.getStyleClass().add("panel");

        Label forecastTitle = panelTitle("CGPA FORECAST");
        Label forecastSub   = new Label("Updates live as you add or remove courses this semester");
        forecastSub.getStyleClass().add("panel-subtitle");

        HBox forecastRow = new HBox(32);
        forecastRow.setAlignment(Pos.CENTER_LEFT);

        // Max
        VBox maxBox = new VBox(4);
        Label maxLbl = fieldLabel("MAX ACHIEVABLE");
        Label maxVal = new Label("—");
        maxVal.getStyleClass().add("forecast-value-good");
        maxVal.textProperty().bind(
            Bindings.createStringBinding(() -> DF.format(service.maxCgpaProperty().get()), service.maxCgpaProperty()));
        maxBox.getChildren().addAll(maxLbl, maxVal);

        // Min
        VBox minBox = new VBox(4);
        Label minLbl = fieldLabel("MIN IF ALL FAIL");
        Label minVal = new Label("—");
        minVal.getStyleClass().add("forecast-value-bad");
        minVal.textProperty().bind(
            Bindings.createStringBinding(() -> DF.format(service.minCgpaProperty().get()), service.minCgpaProperty()));
        minBox.getChildren().addAll(minLbl, minVal);

        // Grade range bar
        VBox barBox = new VBox(6);
        HBox.setHgrow(barBox, Priority.ALWAYS);
        barBox.setAlignment(Pos.CENTER_LEFT);
        Label barLbl = fieldLabel("GRADE RANGE  (max → 4.00 scale)");
        ProgressBar bar = new ProgressBar(0);
        bar.getStyleClass().add("forecast-bar");
        bar.setMaxWidth(Double.MAX_VALUE);
        bar.setPrefHeight(10);
        bar.progressProperty().bind(
            Bindings.createDoubleBinding(() -> service.maxCgpaProperty().get() / 4.0, service.maxCgpaProperty()));
        barBox.getChildren().addAll(barLbl, bar);

        forecastRow.getChildren().addAll(maxBox, minBox, barBox);
        forecastPanel.getChildren().addAll(forecastTitle, forecastSub, forecastRow);

        // ── Student profile info panel ────────────────────────────────────────
        VBox infoPanel = new VBox(16);
        infoPanel.getStyleClass().add("panel");

        Label infoTitle = panelTitle("STUDENT PROFILE");

        GridPane grid = new GridPane();
        grid.setHgap(48);
        grid.setVgap(12);

        addRow(grid, 0, "STUDENT NAME",     service.studentNameProperty().get());
        addRow(grid, 1, "STUDENT ID",       service.studentIdProperty().get());
        addRow(grid, 2, "STARTING SEMESTER",service.startingSemesterProperty().get());
        addRow(grid, 3, "DAILY STUDY HOURS",String.format("%.0f hrs", service.studyHoursProperty().get()));

        service.studentNameProperty().addListener((o, ov, nv)   -> updateRow(grid, 0, nv));
        service.startingSemesterProperty().addListener((o,ov,nv) -> updateRow(grid, 2, nv));
        service.studyHoursProperty().addListener((o, ov, nv)     -> updateRow(grid, 3, String.format("%.0f hrs", nv.doubleValue())));

        infoPanel.getChildren().addAll(infoTitle, grid);

        // ── Planned courses chip row ──────────────────────────────────────────
        HBox chipRow = new HBox(10);
        chipRow.setAlignment(Pos.CENTER_LEFT);
        Label chipLbl = fieldLabel("THIS SEMESTER :");

        Label courseChip = new Label();
        courseChip.getStyleClass().add("chip-blue");
        courseChip.textProperty().bind(Bindings.createStringBinding(() ->
            service.plannedCoursesProperty().filtered(c -> !c.isLab()).size() + " courses planned",
            service.plannedCoursesProperty()));

        Label creditChip = new Label();
        creditChip.getStyleClass().add("chip-cyan");
        creditChip.textProperty().bind(Bindings.createStringBinding(() ->
            service.plannedCoursesProperty().stream().mapToInt(c -> c.getCredits()).sum() + " credits",
            service.plannedCoursesProperty()));

        chipRow.getChildren().addAll(chipLbl, courseChip, creditChip);

        // ── Save location info ────────────────────────────────────────────────
        Label saveLbl = new Label();
        saveLbl.getStyleClass().add("save-path-label");
        saveLbl.textProperty().bind(
            Bindings.createStringBinding(() ->
                "💾  Data saved to: " + service.saveLocationProperty().get(),
                service.saveLocationProperty()));
        saveLbl.setWrapText(true);

        root.getChildren().addAll(header, cardRow, forecastPanel, infoPanel, chipRow, saveLbl);
        setContent(root);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private VBox pageHeader(String title, String sub) {
        Label t = new Label(title.toUpperCase());
        t.getStyleClass().add("page-title");
        Label s = new Label(sub);
        s.getStyleClass().add("page-subtitle");
        VBox b = new VBox(4, t, s);
        return b;
    }

    private Label panelTitle(String text) {
        Label l = new Label("▪  " + text);
        l.getStyleClass().add("panel-title");
        return l;
    }

    private Label fieldLabel(String text) {
        Label l = new Label(text);
        l.getStyleClass().add("field-label");
        return l;
    }

    private void addRow(GridPane grid, int row, String key, String value) {
        Label k = fieldLabel(key);
        Label v = new Label(value);
        v.getStyleClass().add("grid-value");
        grid.add(k, 0, row);
        grid.add(v, 1, row);
    }

    private void updateRow(GridPane grid, int row, String newValue) {
        grid.getChildren().stream()
            .filter(n -> GridPane.getRowIndex(n) != null
                      && GridPane.getRowIndex(n) == row
                      && GridPane.getColumnIndex(n) != null
                      && GridPane.getColumnIndex(n) == 1)
            .findFirst()
            .ifPresent(n -> ((Label) n).setText(newValue));
    }
}
