package com.bracu.studyplanner.view.components;

import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

/**
 * Reusable stat card for the dashboard top row.
 *
 * Usage:
 *   StatCard card = new StatCard("CURRENT CGPA", StatCard.Variant.ACCENT);
 *   card.valueLabelProperty().textProperty().bind(…);
 */
public class StatCard extends VBox {

    public enum Variant { DEFAULT, ACCENT }

    private final Label valueLabel;

    public StatCard(String title, Variant variant) {
        super(8);
        getStyleClass().add(variant == Variant.ACCENT ? "stat-card-accent" : "stat-card");

        Label titleLabel = new Label(title);
        titleLabel.getStyleClass().add("stat-card-title");

        valueLabel = new Label("—");
        valueLabel.getStyleClass().add(variant == Variant.ACCENT ? "stat-card-value-accent" : "stat-card-value");
        valueLabel.setWrapText(true);

        getChildren().addAll(titleLabel, valueLabel);
    }

    /** Returns the value label so callers can bind its text property. */
    public Label valueLabelProperty() {
        return valueLabel;
    }
}
