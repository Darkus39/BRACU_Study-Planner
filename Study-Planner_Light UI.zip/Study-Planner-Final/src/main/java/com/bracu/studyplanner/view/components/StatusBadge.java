package com.bracu.studyplanner.view.components;

import javafx.scene.control.Label;

/**
 * Inline status/error badge — hidden by default, shown by calling show(text).
 *
 * Usage:
 *   StatusBadge badge = new StatusBadge();
 *   badge.show("⚠  Something went wrong");
 *   badge.hide();
 */
public class StatusBadge extends Label {

    public StatusBadge() {
        getStyleClass().add("status-badge");
        setVisible(false);
        setManaged(false);
        setWrapText(true);
    }

    public void show(String message) {
        setText(message);
        setVisible(true);
        setManaged(true);
    }

    public void hide() {
        setVisible(false);
        setManaged(false);
    }
}
