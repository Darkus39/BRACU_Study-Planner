package com.bracu.studyplanner.view.screens;

import com.bracu.studyplanner.service.StudentService;
import com.bracu.studyplanner.view.screens.tabs.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.*;

/**
 * Main application shell after profile creation.
 *
 * Layout:
 *   ┌─────────────┬──────────────────────────────────────────────┐
 *   │  SIDEBAR    │  CONTENT AREA (swapped per nav selection)    │
 *   │  • Logo     │                                              │
 *   │  • Nav btns │                                              │
 *   │  • Footer   │                                              │
 *   └─────────────┴──────────────────────────────────────────────┘
 *
 * The sidebar is always visible; only the right-hand content panel swaps.
 */
public class MainScreen extends HBox {

    private final StackPane contentArea = new StackPane();

    public MainScreen(StudentService service, Runnable onReset) {
        getStyleClass().add("main-screen");
        setFillHeight(true);

        // ── Sidebar ───────────────────────────────────────────────────────────
        VBox sidebar = buildSidebar(service, onReset);
        HBox.setHgrow(contentArea, Priority.ALWAYS);
        contentArea.getStyleClass().add("content-area");

        getChildren().addAll(sidebar, contentArea);

        // ── Default tab ───────────────────────────────────────────────────────
        showTab(new DashboardTab(service));
    }

    // ── Sidebar ───────────────────────────────────────────────────────────────

    private VBox buildSidebar(StudentService service, Runnable onReset) {
        VBox sidebar = new VBox();
        sidebar.getStyleClass().add("sidebar");
        sidebar.setPrefWidth(210);
        sidebar.setMinWidth(210);
        sidebar.setMaxWidth(210);
        sidebar.setFillWidth(true);

        // Logo area
        VBox logoBox = new VBox(4);
        logoBox.getStyleClass().add("sidebar-logo");
        Label logo    = new Label("SP");
        logo.getStyleClass().add("logo-mark");
        Label logoText = new Label("Study Planner");
        logoText.getStyleClass().add("logo-text");
        Label logoBadge = new Label("BRACU");
        logoBadge.getStyleClass().add("logo-badge");
        logoBox.getChildren().addAll(logo, logoText, logoBadge);

        // Navigation items
        VBox nav = new VBox(4);
        nav.getStyleClass().add("sidebar-nav");
        nav.setPadding(new Insets(8, 0, 8, 0));

        NavButton btnDash     = new NavButton("⬛  Dashboard",     true);
        NavButton btnCourses  = new NavButton("⊞  Courses",        false);
        NavButton btnSchedule = new NavButton("⊟  Study Schedule", false);
        NavButton btnSettings = new NavButton("⊡  Settings",       false);

        btnDash.setOnAction(e -> { selectNav(btnDash, btnCourses, btnSchedule, btnSettings); showTab(new DashboardTab(service)); });
        btnCourses.setOnAction(e -> { selectNav(btnCourses, btnDash, btnSchedule, btnSettings); showTab(new CoursesTab(service)); });
        btnSchedule.setOnAction(e -> { selectNav(btnSchedule, btnDash, btnCourses, btnSettings); showTab(new ScheduleTab(service)); });
        btnSettings.setOnAction(e -> { selectNav(btnSettings, btnDash, btnCourses, btnSchedule); showTab(new SettingsTab(service, onReset)); });

        nav.getChildren().addAll(btnDash, btnCourses, btnSchedule, btnSettings);

        // Spacer
        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);

        // Student card at bottom
        VBox studentCard = new VBox(3);
        studentCard.getStyleClass().add("sidebar-student-card");
        Label nameLabel = new Label();
        nameLabel.getStyleClass().add("sidebar-student-name");
        nameLabel.textProperty().bind(service.studentNameProperty());
        nameLabel.setWrapText(true);

        Label idLabel = new Label();
        idLabel.getStyleClass().add("sidebar-student-id");
        idLabel.textProperty().bind(service.studentIdProperty());

        // Status bar
        Label status = new Label();
        status.getStyleClass().add("status-bar");
        status.textProperty().bind(service.statusMessageProperty());
        status.setWrapText(true);
        VBox.setMargin(status, new Insets(8, 0, 0, 0));

        studentCard.getChildren().addAll(nameLabel, idLabel, status);

        sidebar.getChildren().addAll(logoBox, nav, spacer, studentCard);
        return sidebar;
    }


    private void showTab(javafx.scene.Node tab) {
        contentArea.getChildren().setAll(tab);
    }

    private void selectNav(NavButton selected, NavButton... others) {
        selected.setSelected(true);
        for (NavButton b : others) b.setSelected(false);
    }

    // ── NavButton inner class ────────────────────────────────────────────────

    public static class NavButton extends javafx.scene.control.Button {
        public NavButton(String text, boolean selected) {
            super(text);
            getStyleClass().add("nav-btn");
            setMaxWidth(Double.MAX_VALUE);
            setSelected(selected);
        }

        public void setSelected(boolean selected) {
            if (selected) {
                if (!getStyleClass().contains("nav-btn-active")) getStyleClass().add("nav-btn-active");
            } else {
                getStyleClass().remove("nav-btn-active");
            }
        }
    }
}
