package com.bracu.studyplanner.view.components;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;

/**
 * Reusable labelled text-field component used in the setup wizard.
 *
 * Usage:
 *   FormField f = new FormField("FULL NAME", "e.g. Arif Hossain");
 *   TextField input = f.getInput();
 */
public class FormField extends VBox {

    private final TextField input;

    public FormField(String labelText, String promptText) {
        super(6);
        setMaxWidth(Double.MAX_VALUE);

        Label label = new Label(labelText);
        label.getStyleClass().add("field-label");

        input = new TextField();
        input.setPromptText(promptText);
        input.getStyleClass().add("text-field");
        input.setMaxWidth(Double.MAX_VALUE);

        getChildren().addAll(label, input);
    }

    public TextField getInput() {
        return input;
    }
}
