package com.bracu.studyplanner.service;

import com.bracu.studyplanner.model.CourseEntry;
import com.bracu.studyplanner.model.Student;
import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Central Spring service — the single source of truth for all student state.
 *
 * Exposes JavaFX Observable properties so that UI components can bind directly
 * without manual refresh calls. All mutations that affect the UI must be
 * dispatched on the JavaFX Application Thread (the caller's responsibility —
 * use Platform.runLater() when calling from a background thread).
 *
 * Injected Spring dependencies:
 *   - PersistenceService  → JSON load/save
 *   - CourseRepository    → course database lookup
 *   - CgpaService         → CGPA calculations
 */
@Service
public class StudentService {

    private final PersistenceService persistence;
    private final CourseRepository   courses;
    private final CgpaService        cgpaService;

    // ── Observable UI properties ─────────────────────────────────────────────

    private final StringProperty  studentName      = new SimpleStringProperty("");
    private final StringProperty  studentId        = new SimpleStringProperty("");
    private final DoubleProperty  cgpa             = new SimpleDoubleProperty(0.0);
    private final IntegerProperty completedCourses = new SimpleIntegerProperty(0);
    private final StringProperty  currentSemester  = new SimpleStringProperty("");
    private final StringProperty  semesterCount    = new SimpleStringProperty("");
    private final StringProperty  startingSemester = new SimpleStringProperty("");
    private final DoubleProperty  studyHours       = new SimpleDoubleProperty(4.0);
    private final DoubleProperty  maxCgpa          = new SimpleDoubleProperty(0.0);
    private final DoubleProperty  minCgpa          = new SimpleDoubleProperty(0.0);
    private final StringProperty  statusMessage    = new SimpleStringProperty("Ready.");
    private final StringProperty  saveLocation     = new SimpleStringProperty("");

    private final ObservableList<CourseEntry> plannedCourses =
        FXCollections.observableArrayList();

    private Student student;

    // ── Constructor (Spring injects all dependencies) ────────────────────────

    public StudentService(PersistenceService persistence,
                          CourseRepository   courses,
                          CgpaService        cgpaService) {
        this.persistence  = persistence;
        this.courses      = courses;
        this.cgpaService  = cgpaService;
        saveLocation.set(persistence.getSaveLocation());

        // Load existing profile on startup
        Student loaded = persistence.load();
        if (loaded != null) applyStudent(loaded);
    }

    // ── Profile management ───────────────────────────────────────────────────

    /**
     * Creates and persists a new profile.
     * Returns null on success, or a user-facing error message.
     */
    public String createProfile(String name, String id, double cgpaVal, int completedCount) {
        if (name == null || name.isBlank())
            return "Name cannot be empty.";
        if (id == null || !id.matches("\\d+"))
            return "Student ID must contain only digits.";
        if (cgpaVal < 0.0 || cgpaVal > 4.0)
            return "CGPA must be between 0.00 and 4.00.";
        if (completedCount < 0)
            return "Completed courses cannot be negative.";

        student = new Student(name.trim(), id.trim(), cgpaVal, completedCount);
        applyStudent(student);
        persistence.save(student);
        return null; // success
    }

    /** Wipes current in-memory state. Called before showing the setup screen again. */
    public void clearProfile() {
        student = null;
        studentName.set("");
        studentId.set("");
        cgpa.set(0.0);
        completedCourses.set(0);
        currentSemester.set("");
        semesterCount.set("");
        startingSemester.set("");
        studyHours.set(4.0);
        plannedCourses.clear();
        maxCgpa.set(0.0);
        minCgpa.set(0.0);
    }

    public boolean hasProfile() {
        return student != null;
    }

    // ── Course management ────────────────────────────────────────────────────

    /**
     * Adds a theory course (and its lab if one exists).
     * Returns null on success, or a user-facing error message.
     */
    public String addCourse(String code) {
        if (student == null) return "No student profile loaded.";
        String upper = code.toUpperCase().trim();

        if (getTheoryCount() >= 5)
            return "Maximum limit of 5 theory courses reached.";
        if (!courses.exists(upper))
            return "Course " + upper + " not found in the database.";
        for (CourseEntry e : plannedCourses) {
            if (e.getCode().equalsIgnoreCase(upper))
                return "Course " + upper + " is already in your plan.";
        }

        plannedCourses.add(new CourseEntry(
            upper,
            courses.getName(upper),
            courses.getCredits(upper),
            courses.getWeight(upper),
            false,   // lab
            false,   // retake — new courses default to first attempt
            0,       // studiedMinutesToday
            ""       // lastStudyDate
        ));

        // Auto-add lab companion if it exists
        String labCode = upper + "L";
        if (courses.exists(labCode)) {
            plannedCourses.add(new CourseEntry(labCode, courses.getName(labCode), 0, 0, true, false, 0, ""));
        }

        syncAndSave();
        setStatus("Added " + upper + (courses.exists(labCode) ? " + Lab" : "") + ".");
        return null;
    }

    /**
     * Removes a theory course (and its lab).
     * Returns null on success, or a user-facing error message.
     */
    public String removeCourse(String code) {
        if (student == null) return "No student profile loaded.";
        String upper = code.toUpperCase().trim();

        if (getTheoryCount() - 1 < 2)
            return "Cannot drop below 2 courses (BRACU minimum requirement).";

        List<CourseEntry> toRemove = new ArrayList<>();
        boolean found = false;
        for (CourseEntry e : plannedCourses) {
            if (e.getCode().equalsIgnoreCase(upper))       { toRemove.add(e); found = true; }
            if (e.getCode().equalsIgnoreCase(upper + "L")) { toRemove.add(e); }
        }
        if (!found) return "Course " + upper + " not found in your plan.";

        plannedCourses.removeAll(toRemove);
        syncAndSave();
        setStatus("Removed " + upper + ".");
        return null;
    }

    /** Called by the UI when a course's retake flag changes. */
    public void syncAndSavePublic() { syncAndSave(); }

    /**
     * Logs manually-entered study minutes for a course.
     * Triggers a save so the progress survives app restarts within the same day.
     */
    public void logStudyTime(String courseCode, int minutes) {
        if (student == null) return;
        plannedCourses.stream()
            .filter(e -> e.getCode().equalsIgnoreCase(courseCode))
            .findFirst()
            .ifPresent(e -> e.logStudyMinutes(minutes));
        syncAndSave();
    }

    /** Updates the daily study hours preference. */
    public void updateStudyHours(double hours) {
        if (student == null) return;
        student.setStudyHoursPerDay(hours);
        studyHours.set(hours);
        persistence.save(student);
    }

    // ── Semester finalization ────────────────────────────────────────────────

    /**
     * Finalizes the semester with the given GPA:
     *   1. Recalculates cumulative CGPA
     *   2. Increments completed course count
     *   3. Rotates semester name and ordinal
     *   4. Clears planned courses
     *   5. Persists
     *
     * Returns null on success, or a user-facing error message.
     */
    public String finalizeSemester(double semesterGpa) {
        if (student == null) return "No student profile loaded.";
        if (getTheoryCount() == 0) return "Add courses before finalizing.";
        if (semesterGpa < 0.0 || semesterGpa > 4.0)
            return "Semester GPA must be between 0.00 and 4.00.";

        int theoryCount    = getTheoryCount();
        int nonRetakeCount = getNonRetakeTheoryCount();

        double newCgpa = cgpaService.finalizeCgpa(
            student.getCgpa(), student.getCompletedCreditCourses(), semesterGpa, nonRetakeCount
        );

        student.setCompletedCreditCourses(student.getCompletedCreditCourses() + nonRetakeCount);
        student.setCgpa(newCgpa);

        String newSemName = rotateSemesterName(student.getCurrentSemester());
        int    nextNum    = parseOrdinalNumber(student.getSemesterCount()) + 1;
        student.setCurrentSemester(newSemName);
        student.setSemesterCount(nextNum + ordinalSuffix(nextNum));

        student.getPlannedCourses().clear();
        plannedCourses.clear();

        // Sync all observable properties
        cgpa.set(newCgpa);
        completedCourses.set(student.getCompletedCreditCourses());
        currentSemester.set(newSemName);
        semesterCount.set(student.getSemesterCount());
        refreshCgpaForecast();

        persistence.save(student);
        int retakeCount = theoryCount - nonRetakeCount;
        String retakeNote = retakeCount > 0 ? " (" + retakeCount + " retake" + (retakeCount > 1 ? "s" : "") + " excluded from credit count)" : "";
        setStatus(String.format(
            "Semester finalized! New CGPA: %.2f%s · Welcome to %s!", newCgpa, retakeNote, newSemName));
        return null;
    }

    // ── Reset ────────────────────────────────────────────────────────────────

    public boolean resetProfile() {
        boolean deleted = persistence.deleteSaveFile();
        clearProfile();
        return deleted;
    }

    // ── Internal helpers ─────────────────────────────────────────────────────

    private void applyStudent(Student s) {
        this.student = s;
        studentName.set(s.getName()      != null ? s.getName()      : "");
        studentId.set(s.getId()          != null ? s.getId()        : "");
        cgpa.set(s.getCgpa());
        completedCourses.set(s.getCompletedCreditCourses());
        currentSemester.set(s.getCurrentSemester()   != null ? s.getCurrentSemester()  : "");
        semesterCount.set(s.getSemesterCount()        != null ? s.getSemesterCount()    : "");
        startingSemester.set(s.getStartingSemester()  != null ? s.getStartingSemester(): "");
        studyHours.set(s.getStudyHoursPerDay());

        plannedCourses.clear();
        if (s.getPlannedCourses() != null) {
            s.getPlannedCourses().forEach(com.bracu.studyplanner.model.CourseEntry::resetIfNewDay);
            plannedCourses.addAll(s.getPlannedCourses());
        }
        refreshCgpaForecast();
    }

    private void syncAndSave() {
        if (student != null) student.setPlannedCourses(new ArrayList<>(plannedCourses));
        refreshCgpaForecast();
        persistence.save(student);
    }

    private void refreshCgpaForecast() {
        int theory = getTheoryCount();
        if (student != null && theory > 0) {
            maxCgpa.set(cgpaService.maxAchievable(student.getCgpa(), student.getCompletedCreditCourses(), theory));
            minCgpa.set(cgpaService.minIfAllFail (student.getCgpa(), student.getCompletedCreditCourses(), theory));
        } else {
            double base = student != null ? student.getCgpa() : 0.0;
            maxCgpa.set(base);
            minCgpa.set(base);
        }
    }

    private int getTheoryCount() {
        return (int) plannedCourses.stream().filter(e -> !e.isLab()).count();
    }

    private int getNonRetakeTheoryCount() {
        return (int) plannedCourses.stream().filter(e -> !e.isLab() && !e.isRetake()).count();
    }

    private String rotateSemesterName(String current) {
        if (current == null) return "Spring 2025";
        String[] parts = current.split(" ");
        if (parts.length < 2) return current;
        int year;
        try { year = Integer.parseInt(parts[1]); } catch (NumberFormatException e) { return current; }
        return switch (parts[0].toLowerCase()) {
            case "spring" -> "Summer " + year;
            case "summer" -> "Fall "   + year;
            case "fall"   -> "Spring " + (year + 1);
            default       -> current;
        };
    }

    private int parseOrdinalNumber(String s) {
        if (s == null) return 0;
        try { return Integer.parseInt(s.replaceAll("[^0-9]", "")); }
        catch (NumberFormatException e) { return 0; }
    }

    private String ordinalSuffix(int n) {
        if (n >= 11 && n <= 13) return "th";
        return switch (n % 10) {
            case 1  -> "st";
            case 2  -> "nd";
            case 3  -> "rd";
            default -> "th";
        };
    }

    public void setStatus(String message) { statusMessage.set(message); }

    // ── Observable property accessors (JavaFX binding) ───────────────────────

    public StringProperty  studentNameProperty()      { return studentName; }
    public StringProperty  studentIdProperty()        { return studentId; }
    public DoubleProperty  cgpaProperty()             { return cgpa; }
    public IntegerProperty completedCoursesProperty() { return completedCourses; }
    public StringProperty  currentSemesterProperty()  { return currentSemester; }
    public StringProperty  semesterCountProperty()    { return semesterCount; }
    public StringProperty  startingSemesterProperty() { return startingSemester; }
    public DoubleProperty  studyHoursProperty()       { return studyHours; }
    public DoubleProperty  maxCgpaProperty()          { return maxCgpa; }
    public DoubleProperty  minCgpaProperty()          { return minCgpa; }
    public StringProperty  statusMessageProperty()    { return statusMessage; }
    public StringProperty  saveLocationProperty()     { return saveLocation; }
    public ObservableList<CourseEntry> plannedCoursesProperty() { return plannedCourses; }

    public Student getStudent() { return student; }
}
