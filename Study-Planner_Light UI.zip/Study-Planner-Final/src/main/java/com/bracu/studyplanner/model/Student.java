package com.bracu.studyplanner.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * Core domain model for a BRACU student.
 *
 * Lombok @Data generates: getters, setters, equals, hashCode, toString.
 * Lombok @NoArgsConstructor generates the no-arg constructor Gson needs.
 *
 * Persisted fields are serialized to JSON by GsonPersistenceService.
 * Transient fields (maxCgpa, minCgpa) are recomputed on every load
 * and are excluded from serialization.
 */
@Data
@NoArgsConstructor
public class Student {

    private String name;
    private String id;
    private double cgpa;
    private int    completedCreditCourses;
    private double studyHoursPerDay = 4.0;

    // Semester metadata — derived from ID on first creation, then stored
    private String startingSemester;
    private String currentSemester;
    private String semesterCount;

    // Planned courses for the current semester
    private List<CourseEntry> plannedCourses = new ArrayList<>();

    // Computed CGPA forecast — NOT persisted (transient)
    private transient double maxCgpa;
    private transient double minCgpa;

    // ── Convenience constructor ──────────────────────────────────────────────

    public Student(String name, String id, double cgpa, int completedCreditCourses) {
        this.name                  = name;
        this.id                    = id;
        this.cgpa                  = cgpa;
        this.completedCreditCourses = completedCreditCourses;
        deriveSemesterInfo();
    }

    /**
     * Re-derives semester metadata from the stored student ID.
     * Called after construction and after JSON load.
     * Safe to call multiple times — idempotent.
     */
    public void deriveSemesterInfo() {
        if (id == null || id.isBlank()) return;
        SemesterInfo info = new SemesterInfo(id.trim());
        // Only set if not already overridden by finalize
        if (startingSemester == null) startingSemester = info.getStartingSemester();
        if (currentSemester  == null) currentSemester  = info.getCurrentSemester();
        if (semesterCount    == null) semesterCount     = info.getSemesterCount();
    }

    // ── Computed helpers ─────────────────────────────────────────────────────

    /** Count of theory (non-lab) courses in the plan. */
    public int getTheoryCount() {
        if (plannedCourses == null) return 0;
        return (int) plannedCourses.stream().filter(e -> !e.isLab()).count();
    }

    /** Total planned credits (labs contribute 0). */
    public int getPlannedCredits() {
        if (plannedCourses == null) return 0;
        return plannedCourses.stream().mapToInt(CourseEntry::getCredits).sum();
    }
}
