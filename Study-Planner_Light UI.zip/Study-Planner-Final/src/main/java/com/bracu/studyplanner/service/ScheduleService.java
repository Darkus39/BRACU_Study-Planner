package com.bracu.studyplanner.service;

import com.bracu.studyplanner.model.CourseEntry;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Generates a weighted daily study schedule and topic roadmap.
 * Difficulty weight drives time allocation: Hard = 3× Easy.
 */
@Service
public class ScheduleService {

    // Topic database keyed by course code
    private static final Map<String, String[]> TOPIC_MAP = new HashMap<>();

    static {
        TOPIC_MAP.put("CSE110",  new String[]{"Variables & Data Types", "Control Flow", "Methods & Recursion", "Arrays"});
        TOPIC_MAP.put("CSE111",  new String[]{"OOP Fundamentals", "Inheritance", "Interfaces", "Exception Handling"});
        TOPIC_MAP.put("CSE220",  new String[]{"Linked Lists", "Stacks & Queues", "Trees & BST", "Hash Tables"});
        TOPIC_MAP.put("CSE221",  new String[]{"BFS / DFS", "Greedy Algorithms", "Dynamic Programming", "Graph Theory"});
        TOPIC_MAP.put("CSE310",  new String[]{"Classes & Objects", "Polymorphism", "Design Patterns", "Collections"});
        TOPIC_MAP.put("CSE321",  new String[]{"Process Management", "Memory Management", "File Systems", "Synchronization"});
        TOPIC_MAP.put("CSE370",  new String[]{"ER Diagrams", "SQL Fundamentals", "Normalization", "Transactions"});
        TOPIC_MAP.put("CSE422",  new String[]{"Search Algorithms", "Knowledge Representation", "ML Basics", "Neural Networks"});
        TOPIC_MAP.put("CSE427",  new String[]{"Supervised Learning", "Unsupervised Learning", "Feature Engineering", "Model Evaluation"});
        TOPIC_MAP.put("MAT110",  new String[]{"Limits & Continuity", "Derivatives", "Integration", "Series"});
        TOPIC_MAP.put("MAT120",  new String[]{"Integral Calculus", "Differential Equations", "Laplace Transforms", "Series Solutions"});
        TOPIC_MAP.put("MAT215",  new String[]{"Vectors & Matrices", "Linear Transformations", "Eigenvalues", "Vector Spaces"});
        TOPIC_MAP.put("PHY111",  new String[]{"Mechanics", "Kinematics", "Work & Energy", "Oscillations"});
        TOPIC_MAP.put("PHY112",  new String[]{"Electromagnetism", "Waves", "Optics", "Modern Physics"});
        TOPIC_MAP.put("ENG101",  new String[]{"Grammar Fundamentals", "Paragraph Writing", "Essay Structure", "Critical Reading"});
        TOPIC_MAP.put("ENG103",  new String[]{"Academic Writing", "Presentation Skills", "Research Methods", "Argumentation"});
    }

    // ── Schedule generation ──────────────────────────────────────────────────

    public record ScheduleEntry(String code, String name, int minutes, int weight, String diffLabel) {}

    public record RoadmapEntry(String code, String name, List<String> topics) {}

    /**
     * Builds a daily time-allocation plan.
     * Time is distributed proportionally to course difficulty weight.
     */
    public List<ScheduleEntry> generateSchedule(List<CourseEntry> courses, double totalHours) {
        if (courses == null || courses.isEmpty()) return List.of();

        List<CourseEntry> theory = courses.stream().filter(e -> !e.isLab()).toList();
        int totalWeight = theory.stream().mapToInt(CourseEntry::getDifficultyWeight).sum();
        if (totalWeight == 0) return List.of();

        double totalMinutes = totalHours * 60.0;
        List<ScheduleEntry> result = new ArrayList<>();
        for (CourseEntry e : theory) {
            int mins = (int) Math.round((e.getDifficultyWeight() / (double) totalWeight) * totalMinutes);
            result.add(new ScheduleEntry(e.getCode(), e.getName(), mins,
                e.getDifficultyWeight(), e.getDifficultyLabel()));
        }
        return result;
    }

    /** Returns a topic roadmap for each theory course. */
    public List<RoadmapEntry> generateRoadmap(List<CourseEntry> courses) {
        if (courses == null) return List.of();
        List<RoadmapEntry> result = new ArrayList<>();
        for (CourseEntry e : courses) {
            if (e.isLab()) continue;
            String[] topics = TOPIC_MAP.getOrDefault(e.getCode().toUpperCase(),
                new String[]{"Review Lecture Notes", "Attempt Past Papers", "Solve Practice Problems"});
            result.add(new RoadmapEntry(e.getCode(), e.getName(), Arrays.asList(topics)));
        }
        return result;
    }
}
