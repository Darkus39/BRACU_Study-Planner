package com.bracu.studyplanner.app;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * Spring Boot configuration root.
 *
 * @SpringBootApplication enables:
 *   - @ComponentScan    → auto-discovers @Service, @Component in com.bracu.studyplanner
 *   - @EnableAutoConfiguration → Spring Boot defaults (no web server auto-configured
 *                                because spring-boot-starter-web is NOT on the classpath)
 *   - @Configuration   → this class can declare @Bean methods
 */
@SpringBootApplication
@ComponentScan(basePackages = "com.bracu.studyplanner")
public class SpringConfig {
    // Spring Boot auto-configuration handles the rest.
    // Add @Bean definitions here when you need custom infrastructure beans
    // (e.g., a custom ObjectMapper, an ExecutorService, etc.)
}
