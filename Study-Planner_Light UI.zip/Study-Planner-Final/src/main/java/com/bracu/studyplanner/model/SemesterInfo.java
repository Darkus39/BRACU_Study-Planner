package com.bracu.studyplanner.model;

import java.time.LocalDate;
import java.time.ZoneId;

/**
 * Derives semester metadata from a BRACU student ID.
 *
 * Old 8-digit format:  YY S TTTT  (e.g. 20301234 → 2020, Spring)
 *   digits 0-1 = year offset from 2000
 *   digit  2   = semester code (1=Spring, 2=Fall, 3=Summer) → mapped to index
 *
 * New 10-digit format: assumed Spring 2025 start
 */
public class SemesterInfo {

    private static final String[] SEASONS = {"Spring", "Fall", "Summer"};

    private final int    startYear;
    private final int    startSemCode;
    private final String startingSem;
    private final String currentSem;
    private final int    count;

    public SemesterInfo(String id) {
        // ── Derive starting semester ─────────────────────────────────────────
        if (id.length() == 10) {
            startYear    = 2025;
            startSemCode = 0; // Spring 2025
        } else {
            startYear    = 2000 + Integer.parseInt(id.substring(0, 2));
            startSemCode = Integer.parseInt(id.substring(2, 3)) - 1;
        }
        startingSem = SEASONS[Math.max(0, Math.min(2, startSemCode))] + " " + startYear;

        // ── Derive current semester from today's date ────────────────────────
        LocalDate now           = LocalDate.now(ZoneId.of("Asia/Dhaka"));
        int       currentYear   = now.getYear();
        int       month         = now.getMonthValue();

        int currentSemCode;
        if (month <= 4)      currentSemCode = 0; // Spring  Jan–Apr
        else if (month <= 8) currentSemCode = 2; // Summer  May–Aug
        else                 currentSemCode = 1; // Fall    Sep–Dec

        currentSem = SEASONS[currentSemCode] + " " + currentYear;

        int rawCount = ((currentYear - startYear) * 3) + (currentSemCode - startSemCode) + 1;
        // Correction for students who started in Fall
        if (startSemCode == 1 && currentSemCode == 0 && currentYear > startYear) rawCount--;
        count = rawCount;
    }

    // ── Accessors ────────────────────────────────────────────────────────────

    public String getStartingSemester() { return startingSem; }
    public String getCurrentSemester()  { return currentSem; }

    public String getSemesterCount() {
        int n = Math.max(1, count);
        String suffix;
        if (n >= 11 && n <= 13) {
            suffix = "th";
        } else {
            suffix = switch (n % 10) {
                case 1  -> "st";
                case 2  -> "nd";
                case 3  -> "rd";
                default -> "th";
            };
        }
        return n + suffix;
    }
}
