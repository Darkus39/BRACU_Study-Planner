package com.bracu.studyplanner.view.screens.tabs;

import com.bracu.studyplanner.service.StudentService;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.Optional;

/**
 * Settings tab — displays profile summary, save-file location, and reset option.
 */
public class SettingsTab extends ScrollPane {

    public SettingsTab(StudentService service, Runnable onReset) {
        setFitToWidth(true);
        setHbarPolicy(ScrollBarPolicy.NEVER);
        getStyleClass().add("tab-scroll");

        VBox root = new VBox(28);
        root.getStyleClass().add("tab-root");
        root.setPadding(new Insets(36, 40, 36, 40));

        // ── Page header ───────────────────────────────────────────────────────
        Label title    = new Label("SETTINGS");
        Label subtitle = new Label("Profile · Data · About");
        title.getStyleClass().add("page-title");
        subtitle.getStyleClass().add("page-subtitle");

        // ── Profile summary panel ─────────────────────────────────────────────
        VBox profilePanel = new VBox(16);
        profilePanel.getStyleClass().add("panel");
        profilePanel.getChildren().add(panelTitle("PROFILE INFORMATION"));

        GridPane grid = new GridPane();
        grid.setHgap(48);
        grid.setVgap(12);
        addRow(grid, 0, "Name",              service.studentNameProperty().get());
        addRow(grid, 1, "Student ID",         service.studentIdProperty().get());
        addRow(grid, 2, "Current CGPA",       String.format("%.2f", service.cgpaProperty().get()));
        addRow(grid, 3, "Starting Semester",  service.startingSemesterProperty().get());
        addRow(grid, 4, "Current Semester",   service.currentSemesterProperty().get());
        addRow(grid, 5, "Semester Number",    service.semesterCountProperty().get());
        addRow(grid, 6, "Completed Courses",  String.valueOf(service.completedCoursesProperty().get()));
        profilePanel.getChildren().add(grid);

        // ── Data file panel ───────────────────────────────────────────────────
        VBox dataPanel = new VBox(16);
        dataPanel.getStyleClass().add("panel");
        dataPanel.getChildren().add(panelTitle("DATA STORAGE"));

        Label pathLbl = new Label("Your student data is saved locally on your device:");
        pathLbl.getStyleClass().add("panel-subtitle");

        Label pathVal = new Label(service.saveLocationProperty().get());
        pathVal.getStyleClass().add("path-display");
        pathVal.setWrapText(true);

        Label note = new Label(
            "No data ever leaves your device. " +
            "You can back up or copy this file manually at any time.");
        note.getStyleClass().add("panel-subtitle");
        note.setWrapText(true);

        dataPanel.getChildren().addAll(pathLbl, pathVal, note);

        // ── Danger zone panel ─────────────────────────────────────────────────
        VBox dangerPanel = new VBox(16);
        dangerPanel.getStyleClass().add("panel-danger");

        Label dangerTitle = new Label("▪  DANGER ZONE");
        dangerTitle.getStyleClass().add("panel-title-danger");

        Label dangerNote = new Label(
            "Resetting your profile permanently deletes all saved data, " +
            "including your CGPA history, planned courses, and settings. " +
            "This action cannot be undone.");
        dangerNote.getStyleClass().add("panel-subtitle");
        dangerNote.setWrapText(true);

        Button resetBtn = new Button("RESET PROFILE  ×");
        resetBtn.getStyleClass().add("btn-danger");
        resetBtn.setOnAction(e -> {
            Optional<ButtonType> confirm = showConfirm(
                "Reset Profile",
                "This will permanently delete all your data.\nAre you absolutely sure?"
            );
            confirm.ifPresent(bt -> {
                if (bt == ButtonType.OK) {
                    service.resetProfile();
                    Platform.runLater(onReset);
                }
            });
        });

        dangerPanel.getChildren().addAll(dangerTitle, dangerNote, resetBtn);

        // ── About panel ───────────────────────────────────────────────────────
        VBox aboutPanel = new VBox(10);
        aboutPanel.getStyleClass().add("panel");
        aboutPanel.getChildren().add(panelTitle("ABOUT"));

        String[][] info = {
            {"Application",  "BRACU Study Planner"},
            {"Version",      "2.0.0"},
            {"Stack",        "Java 21 · Spring Boot 3.2 · JavaFX 21"},
            {"Architecture", "Spring DI + JavaFX MVVM"},
            {"Persistence",  "JSON (local file, cross-platform)"},
            {"Installer",    "jpackage — native .exe / .dmg / .rpm / .deb"},
        };
        GridPane aboutGrid = new GridPane();
        aboutGrid.setHgap(40);
        aboutGrid.setVgap(10);
        for (int i = 0; i < info.length; i++) {
            addRow(aboutGrid, i, info[i][0], info[i][1]);
        }
        aboutPanel.getChildren().add(aboutGrid);

        root.getChildren().addAll(
            new VBox(4, title, subtitle),
            profilePanel,
            dataPanel,
            dangerPanel,
            aboutPanel
        );
        setContent(root);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private Label panelTitle(String text) {
        Label l = new Label("▪  " + text);
        l.getStyleClass().add("panel-title");
        return l;
    }

    private void addRow(GridPane grid, int row, String key, String value) {
        Label k = new Label(key);
        k.getStyleClass().add("field-label");
        Label v = new Label(value != null ? value : "—");
        v.getStyleClass().add("grid-value");
        v.setWrapText(true);
        grid.add(k, 0, row);
        grid.add(v, 1, row);
    }

    private Optional<ButtonType> showConfirm(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, message, ButtonType.OK, ButtonType.CANCEL);
        alert.setTitle(title);
        alert.setHeaderText(title);
        alert.getDialogPane().getStylesheets().add(
            getClass().getResource("/com/bracu/studyplanner/css/app.css").toExternalForm());
        alert.getDialogPane().getStyleClass().add("dialog-pane");
        return alert.showAndWait();
    }
}
