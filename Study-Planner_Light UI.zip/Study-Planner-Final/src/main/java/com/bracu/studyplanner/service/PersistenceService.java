package com.bracu.studyplanner.service;

import com.bracu.studyplanner.model.Student;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.*;

/**
 * Spring-managed persistence service.
 *
 * Save location strategy (cross-platform):
 *   Windows → %USERPROFILE%\Documents\BRACUStudyPlanner\student_data.json
 *   macOS   → ~/Documents/BRACUStudyPlanner/student_data.json
 *   Linux   → ~/BRACUStudyPlanner/student_data.json
 *
 * This keeps data in a predictable, user-accessible location — not buried
 * in a temp directory — and survives app reinstalls.
 */
@Service
public class PersistenceService {

    private static final String APP_FOLDER = "BRACUStudyPlanner";
    private static final String FILE_NAME  = "student_data.json";

    private final Gson   gson    = new GsonBuilder().setPrettyPrinting().create();
    private final Path   savePath;

    public PersistenceService() {
        savePath = resolveSavePath();
        ensureDirectoryExists();
    }

    // ── Public API ───────────────────────────────────────────────────────────

    public void save(Student student) {
        try (Writer writer = new FileWriter(savePath.toFile())) {
            gson.toJson(student, writer);
        } catch (IOException e) {
            System.err.println("[PersistenceService] Save failed: " + e.getMessage());
        }
    }

    /**
     * Loads the student from disk.
     * Returns null if no save file exists or the file is corrupted.
     */
    public Student load() {
        if (!Files.exists(savePath)) return null;
        try (Reader reader = new FileReader(savePath.toFile())) {
            Student student = gson.fromJson(reader, Student.class);
            if (student != null) {
                // Re-derive transient semester info (not stored in JSON)
                if (student.getCurrentSemester() == null) {
                    student.deriveSemesterInfo();
                }
            }
            return student;
        } catch (Exception e) {
            System.err.println("[PersistenceService] Load failed (corrupt file?): " + e.getMessage());
            return null;
        }
    }

    public boolean hasSaveFile() {
        return Files.exists(savePath);
    }

    public boolean deleteSaveFile() {
        try {
            return Files.deleteIfExists(savePath);
        } catch (IOException e) {
            return false;
        }
    }

    /** Exposes the save path so the UI can show "Saved to: …" feedback. */
    public String getSaveLocation() {
        return savePath.toString();
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private Path resolveSavePath() {
        String os   = System.getProperty("os.name", "").toLowerCase();
        String home = System.getProperty("user.home");

        Path folder;
        if (os.contains("win")) {
            // Windows: prefer Documents if it exists
            Path docs = Path.of(home, "Documents");
            folder = Files.isDirectory(docs)
                ? docs.resolve(APP_FOLDER)
                : Path.of(home, APP_FOLDER);
        } else if (os.contains("mac")) {
            folder = Path.of(home, "Documents", APP_FOLDER);
        } else {
            // Linux / other
            folder = Path.of(home, APP_FOLDER);
        }
        return folder.resolve(FILE_NAME);
    }

    private void ensureDirectoryExists() {
        try {
            Files.createDirectories(savePath.getParent());
        } catch (IOException e) {
            System.err.println("[PersistenceService] Could not create save directory: " + e.getMessage());
        }
    }
}
