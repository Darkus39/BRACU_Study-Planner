#!/usr/bin/env bash
set -euo pipefail

# ─────────────────────────────────────────────────────────
#  BRACU Study Planner v2.0 — Linux Auto Installer
#  Supports: Ubuntu / Debian (apt) · Fedora / RHEL (dnf)
# ─────────────────────────────────────────────────────────

CYAN='\033[0;36m'; GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; NC='\033[0m'

echo ""
echo -e "${CYAN} ═══════════════════════════════════════════════════════"
echo -e "  BRACU Study Planner v2.0 — Linux Auto Installer"
echo -e " ═══════════════════════════════════════════════════════${NC}"
echo ""

# ── Detect package manager ────────────────────────────────
if command -v apt &>/dev/null; then
    PKG="apt"
    echo -e "  Detected: ${GREEN}Debian / Ubuntu${NC} (apt)"
elif command -v dnf &>/dev/null; then
    PKG="dnf"
    echo -e "  Detected: ${GREEN}Fedora / RHEL${NC} (dnf)"
else
    echo -e "${RED}  [ERROR] Unsupported distro. Install JDK 21 and Maven manually.${NC}"
    echo "  JDK:   https://adoptium.net"
    echo "  Maven: https://maven.apache.org/download.cgi"
    exit 1
fi
echo ""

# ── Java 21 ───────────────────────────────────────────────
echo -e "${CYAN}[1/2] Checking Java 21...${NC}"
JAVA_OK=false
if command -v java &>/dev/null; then
    JAVA_VER=$(java -version 2>&1 | awk -F '"' '/version/ {print $2}' | cut -d'.' -f1)
    if [[ "$JAVA_VER" -ge 21 ]] 2>/dev/null; then
        JAVA_OK=true
    fi
fi

if [[ "$JAVA_OK" == false ]]; then
    echo -e "${YELLOW}  Java 21+ not found. Installing...${NC}"
    if [[ "$PKG" == "apt" ]]; then
        sudo apt update -qq
        sudo apt install -y openjdk-21-jdk
    else
        sudo dnf install -y java-21-openjdk-devel
    fi
    # Refresh shell's command hash so the new java is visible
    hash -r 2>/dev/null || true
    # Verify java is now accessible
    if ! command -v java &>/dev/null; then
        echo -e "${YELLOW}  [INFO] Java installed but PATH not updated yet.${NC}"
        echo "  Please close this terminal and run install-linux.sh again."
        exit 0
    fi
    echo -e "${GREEN}  [OK] JDK 21 installed.${NC}"
else
    echo -e "${GREEN}  [OK] Java $JAVA_VER found.${NC}"
fi

# ── Maven ─────────────────────────────────────────────────
echo -e "${CYAN}[2/2] Checking Maven...${NC}"
MVN_JUST_INSTALLED=false
if ! command -v mvn &>/dev/null; then
    echo -e "${YELLOW}  Maven not found. Installing...${NC}"
    if [[ "$PKG" == "apt" ]]; then
        sudo apt install -y maven
    else
        sudo dnf install -y maven
    fi
    # Refresh shell's command hash so the new mvn is visible
    hash -r 2>/dev/null || true
    MVN_JUST_INSTALLED=true
fi

# Locate mvn — needed when it was just installed and PATH may not reflect it yet
MVN_EXE=""
if command -v mvn &>/dev/null; then
    MVN_EXE=$(command -v mvn)
else
    # Try common install locations before giving up
    for candidate in /usr/bin/mvn /usr/share/maven/bin/mvn /opt/maven/bin/mvn; do
        if [[ -x "$candidate" ]]; then
            MVN_EXE="$candidate"
            break
        fi
    done
fi

if [[ -z "$MVN_EXE" ]]; then
    echo -e "${YELLOW}  [INFO] Maven installed but PATH not updated yet.${NC}"
    echo "  Please close this terminal and run install-linux.sh again."
    exit 0
fi

if [[ "$MVN_JUST_INSTALLED" == true ]]; then
    echo -e "${GREEN}  [OK] Maven installed.${NC}"
else
    echo -e "${GREEN}  [OK] Maven $("$MVN_EXE" -version 2>&1 | head -1 | awk '{print $3}') found.${NC}"
fi

# ── Launch ────────────────────────────────────────────────
echo ""
echo -e "${CYAN}  Launching BRACU Study Planner...${NC}"
echo ""

cd "$(dirname "$0")"
"$MVN_EXE" javafx:run

echo ""
echo -e "${GREEN}  Done.${NC}"
