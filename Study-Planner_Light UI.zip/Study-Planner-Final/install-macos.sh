#!/usr/bin/env bash
set -euo pipefail

# ─────────────────────────────────────────────────────────
#  BRACU Study Planner v2.0 — macOS Auto Installer
# ─────────────────────────────────────────────────────────

CYAN='\033[0;36m'; GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; NC='\033[0m'

echo ""
echo -e "${CYAN} ═══════════════════════════════════════════════════════"
echo -e "  BRACU Study Planner v2.0 — macOS Auto Installer"
echo -e " ═══════════════════════════════════════════════════════${NC}"
echo ""

# ── Homebrew ──────────────────────────────────────────────
echo -e "${CYAN}[1/3] Checking Homebrew...${NC}"
if ! command -v brew &>/dev/null; then
    echo -e "${YELLOW}  Homebrew not found. Installing...${NC}"
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    # Add brew to PATH for Apple Silicon
    if [[ -f /opt/homebrew/bin/brew ]]; then
        eval "$(/opt/homebrew/bin/brew shellenv)"
    fi
    echo -e "${GREEN}  [OK] Homebrew installed.${NC}"
else
    echo -e "${GREEN}  [OK] Homebrew found.${NC}"
fi

# ── Java 21 ───────────────────────────────────────────────
echo -e "${CYAN}[2/3] Checking Java 21...${NC}"
JAVA_OK=false
if command -v java &>/dev/null; then
    JAVA_VER=$(java -version 2>&1 | awk -F '"' '/version/ {print $2}' | cut -d'.' -f1)
    if [[ "$JAVA_VER" -ge 21 ]] 2>/dev/null; then
        JAVA_OK=true
    fi
fi

if [[ "$JAVA_OK" == false ]]; then
    echo -e "${YELLOW}  Java 21+ not found. Installing via Homebrew...${NC}"
    brew install --cask temurin@21
    export JAVA_HOME=$(/usr/libexec/java_home -v 21 2>/dev/null || echo "/Library/Java/JavaVirtualMachines/temurin-21.jdk/Contents/Home")
    export PATH="$JAVA_HOME/bin:$PATH"
    echo -e "${GREEN}  [OK] JDK 21 installed.${NC}"
else
    echo -e "${GREEN}  [OK] Java $JAVA_VER found.${NC}"
fi

# ── Maven ─────────────────────────────────────────────────
echo -e "${CYAN}[3/3] Checking Maven...${NC}"
if ! command -v mvn &>/dev/null; then
    echo -e "${YELLOW}  Maven not found. Installing via Homebrew...${NC}"
    brew install maven
    echo -e "${GREEN}  [OK] Maven installed.${NC}"
else
    echo -e "${GREEN}  [OK] Maven $(mvn -version 2>&1 | head -1 | awk '{print $3}') found.${NC}"
fi

# ── Launch ────────────────────────────────────────────────
echo ""
echo -e "${CYAN}  Launching BRACU Study Planner...${NC}"
echo ""

cd "$(dirname "$0")"
mvn javafx:run

echo ""
echo -e "${GREEN}  Done.${NC}"
