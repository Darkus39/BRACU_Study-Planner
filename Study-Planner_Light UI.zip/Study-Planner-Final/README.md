# BRACU Study Planner v2.0

Academic management system for BRACU students — built with **Java 21 · Spring Boot 3.2 · JavaFX 21**.

---

## What's new in v2.0

| Area | Before (v1) | Now (v2) |
|---|---|---|
| Architecture | Plain JavaFX MVC | **Spring Boot + JavaFX** — full DI, service layer |
| UI | Custom JavaFX styling | **Fully redesigned** dark theme — Syne + JetBrains Mono |
| Persistence | Working directory `student_data.json` | **Documents/BRACUStudyPlanner/** (cross-platform) |
| Distribution | Run with `mvn javafx:run` | **jpackage installer** — `.exe` / `.dmg` / `.rpm` / `.deb` |
| Bug fix (Fedora 43) | Freeze on "Initialize Profile" | Fixed with `Platform.runLater()` |

---

## Project structure

```
StudyPlannerFX/
├── src/main/java/com/bracu/studyplanner/
│   ├── app/
│   │   ├── Launcher.java           ← true entry point (separates main from Application)
│   │   ├── StudyPlannerApp.java    ← JavaFX Application root, bootstraps Spring
│   │   └── SpringConfig.java       ← @SpringBootApplication config
│   ├── model/
│   │   ├── Student.java            ← core domain model (Lombok)
│   │   ├── CourseEntry.java        ← single course in semester plan
│   │   └── SemesterInfo.java       ← derives semester from student ID
│   ├── service/                    ← Spring @Service layer (all business logic)
│   │   ├── StudentService.java     ← main orchestrator + JavaFX observable properties
│   │   ├── CgpaService.java        ← CGPA forecast & finalize calculations
│   │   ├── CourseRepository.java   ← course database (loaded from courseList)
│   │   ├── PersistenceService.java ← cross-platform JSON save/load
│   │   └── ScheduleService.java    ← study schedule + topic roadmap generation
│   └── view/
│       ├── screens/
│       │   ├── SetupScreen.java    ← first-launch profile wizard
│       │   ├── MainScreen.java     ← sidebar + content shell
│       │   └── tabs/
│       │       ├── DashboardTab.java
│       │       ├── CoursesTab.java
│       │       ├── ScheduleTab.java
│       │       └── SettingsTab.java
│       └── components/
│           ├── FormField.java
│           ├── StatCard.java
│           └── StatusBadge.java
├── src/main/resources/
│   ├── application.properties      ← Spring Boot config (web=none, banner=off)
│   ├── com/bracu/studyplanner/
│   │   ├── css/app.css             ← full dark-theme stylesheet
│   │   └── data/courseList         ← BRACU course database (~340 courses)
├── build-installer.sh              ← Linux/macOS jpackage script
├── build-installer.bat             ← Windows jpackage script
└── pom.xml                         ← Spring Boot parent POM
```

---

## Running in development

### Prerequisites
- JDK 21 or later (includes `jpackage`)
- Maven 3.8+

### Run directly (development mode)
```bash
mvn javafx:run
```

### Build fat JAR
```bash
mvn clean package
java -jar target/StudyPlannerFX-2.0.0.jar
```

---

## Building the installer

### Linux (Fedora)
```bash
chmod +x build-installer.sh
./build-installer.sh

# Install the RPM
sudo dnf install installer-output/*.rpm

# Or install the DEB (Ubuntu/Debian)
sudo dpkg -i installer-output/*.deb
```

### macOS
```bash
chmod +x build-installer.sh
./build-installer.sh
# Opens installer-output/ — double-click the .dmg
```

### Windows
```
Double-click build-installer.bat
# OR from PowerShell:
.\build-installer.bat
```

The installer **bundles its own JRE** — students do not need Java installed.

---

## Data storage

Student data is saved locally — never leaves the device.

| Platform | Location |
|---|---|
| Windows | `%USERPROFILE%\Documents\BRACUStudyPlanner\student_data.json` |
| macOS | `~/Documents/BRACUStudyPlanner/student_data.json` |
| Linux | `~/BRACUStudyPlanner/student_data.json` |

The file is human-readable JSON and can be backed up or copied manually.

---

## Architecture: why Spring Boot + JavaFX?

Spring Boot provides **dependency injection** so each layer is cleanly separated:

```
JavaFX View  →  StudentService (@Service)  →  PersistenceService (@Service)
                      ↓                              ↓
               CgpaService (@Service)        courseList resource
               CourseRepository (@Component)
```

- `StudentService` exposes **JavaFX Observable properties** — the UI binds directly, no manual refresh calls.
- `PersistenceService` handles all file I/O — the service layer never touches the filesystem directly.
- `CourseRepository` loads the course database once at startup via `@PostConstruct` and holds it in memory.
- `StudyPlannerApp.init()` bootstraps the Spring context **off the JavaFX Application Thread**, then `start()` wires Spring beans into the UI.

---

## Bug fix: "Initialize Profile" freeze on Fedora 43

**Root cause:** The original `SetupView` called `onComplete.run()` synchronously inside a button action handler. On Linux/GTK JavaFX builds, swapping the scene root from within an active event dispatch causes the pulse scheduler to deadlock.

**Fix in `SetupScreen.java`:**
```java
// Before (causes freeze on Linux/GTK):
onComplete.run();

// After (deferred to next FX pulse — safe on all platforms):
Platform.runLater(onComplete);
```

The same pattern is applied in `StudyPlannerApp.java` for all scene-graph swaps initiated from callbacks.
