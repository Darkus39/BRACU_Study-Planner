@echo off
title BRACU Study Planner — Auto Installer
color 0B

echo.
echo  =====================================================
echo   BRACU Study Planner v2.0 — Windows Auto Installer
echo  =====================================================
echo.

:: ── Check for winget ──────────────────────────────────
where winget >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERROR] winget is not available on this system.
    echo  Please update Windows to version 1809 or later,
    echo  or install App Installer from the Microsoft Store.
    echo.
    pause
    exit /b 1
)

:: ── Check Java 21+ ────────────────────────────────────
echo  [1/3] Checking Java...
java -version >nul 2>&1
if %errorlevel% neq 0 (
    echo  Java not found. Installing JDK 21 via winget...
    winget install --id Microsoft.OpenJDK.21 --accept-source-agreements --accept-package-agreements -e
    if %errorlevel% neq 0 (
        echo  [ERROR] Failed to install JDK. Please install manually:
        echo  https://adoptium.net
        pause
        exit /b 1
    )
    echo  [OK] JDK 21 installed.
    :: Refresh PATH
    call refreshenv >nul 2>&1
) else (
    echo  [OK] Java found.
)

:: ── Check Maven ───────────────────────────────────────
echo  [2/3] Checking Maven...
where mvn >nul 2>&1
if %errorlevel% neq 0 (
    echo  Maven not found. Installing via winget...
    winget install --id Apache.Maven --accept-source-agreements --accept-package-agreements -e
    if %errorlevel% neq 0 (
        echo  [ERROR] Failed to install Maven. Please install manually:
        echo  https://maven.apache.org/download.cgi
        pause
        exit /b 1
    )
    echo  [OK] Maven installed.
    call refreshenv >nul 2>&1
) else (
    echo  [OK] Maven found.
)

:: ── Run the app ───────────────────────────────────────
echo  [3/3] Launching BRACU Study Planner...
echo.

cd /d "%~dp0"
mvn javafx:run

if %errorlevel% neq 0 (
    echo.
    echo  [ERROR] The app failed to launch.
    echo  Run with: mvn javafx:run -e   for detailed error output.
    pause
    exit /b 1
)

pause
