package com.bracu.studyplanner.view.screens.tabs;

import com.bracu.studyplanner.service.ScheduleService;
import com.bracu.studyplanner.service.StudentService;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.List;

/**
 * Study Schedule tab — shows weighted daily time allocation and topic roadmap.
 * Regenerates automatically whenever the planned courses list changes.
 */
public class ScheduleTab extends ScrollPane {

    private final StudentService  studentService;
    private final ScheduleService scheduleService;
    private final VBox            scheduleBox;
    private final VBox            roadmapBox;

    public ScheduleTab(StudentService studentService) {
        this.studentService  = studentService;
        this.scheduleService = new ScheduleService(); // lightweight, no Spring needed here

        setFitToWidth(true);
        setHbarPolicy(ScrollBarPolicy.NEVER);
        getStyleClass().add("tab-scroll");

        VBox root = new VBox(28);
        root.getStyleClass().add("tab-root");
        root.setPadding(new Insets(36, 40, 36, 40));

        Label title    = new Label("STUDY SCHEDULE");
        Label subtitle = new Label("Weighted daily plan · Topic roadmap");
        title.getStyleClass().add("page-title");
        subtitle.getStyleClass().add("page-subtitle");

        // ── Daily schedule panel ──────────────────────────────────────────────
        VBox schedPanel = new VBox(14);
        schedPanel.getStyleClass().add("panel");
        schedPanel.getChildren().add(panelTitle("DAILY TIME ALLOCATION"));
        scheduleBox = new VBox(10);
        schedPanel.getChildren().add(scheduleBox);

        // ── Roadmap panel ─────────────────────────────────────────────────────
        VBox roadPanel = new VBox(14);
        roadPanel.getStyleClass().add("panel");
        roadPanel.getChildren().add(panelTitle("TOPIC ROADMAP"));
        roadmapBox = new VBox(14);
        roadPanel.getChildren().add(roadmapBox);

        root.getChildren().addAll(new VBox(4, title, subtitle), schedPanel, roadPanel);
        setContent(root);

        // Rebuild whenever courses change
        studentService.plannedCoursesProperty().addListener(
            (javafx.collections.ListChangeListener<com.bracu.studyplanner.model.CourseEntry>) c -> rebuild());
        rebuild();
    }

    private void rebuild() {
        double hours   = studentService.studyHoursProperty().get();
        var    courses = List.copyOf(studentService.plannedCoursesProperty());

        List<ScheduleService.ScheduleEntry> schedule = scheduleService.generateSchedule(courses, hours);
        List<ScheduleService.RoadmapEntry>  roadmap  = scheduleService.generateRoadmap(courses);

        // ── Schedule cards ────────────────────────────────────────────────────
        scheduleBox.getChildren().clear();
        if (schedule.isEmpty()) {
            scheduleBox.getChildren().add(emptyLabel("Add courses in the Course Manager to generate a schedule."));
        } else {
            for (ScheduleService.ScheduleEntry entry : schedule) {
                scheduleBox.getChildren().add(buildScheduleRow(entry, hours));
            }
        }

        // ── Roadmap cards ─────────────────────────────────────────────────────
        roadmapBox.getChildren().clear();
        if (roadmap.isEmpty()) {
            roadmapBox.getChildren().add(emptyLabel("No courses added yet."));
        } else {
            for (ScheduleService.RoadmapEntry entry : roadmap) {
                roadmapBox.getChildren().add(buildRoadmapCard(entry));
            }
        }
    }

    private HBox buildScheduleRow(ScheduleService.ScheduleEntry entry, double totalHours) {
        HBox row = new HBox(16);
        row.setAlignment(Pos.CENTER_LEFT);
        row.getStyleClass().add("schedule-row");

        // Course code badge
        Label codeLbl = new Label(entry.code());
        codeLbl.getStyleClass().add("schedule-code");
        codeLbl.setMinWidth(90);

        // Course name
        Label nameLbl = new Label(entry.name());
        nameLbl.getStyleClass().add("schedule-name");
        HBox.setHgrow(nameLbl, Priority.ALWAYS);

        // Duration
        int hrs = entry.minutes() / 60;
        int min = entry.minutes() % 60;
        String timeStr = hrs > 0 ? hrs + "h " + min + "m" : min + " min";
        Label timeLbl = new Label(timeStr);
        timeLbl.getStyleClass().add("schedule-time");
        timeLbl.setMinWidth(65);

        // Progress bar (proportion of total)
        ProgressBar bar = new ProgressBar(entry.minutes() / (totalHours * 60.0));
        bar.getStyleClass().add("schedule-bar");
        bar.setPrefWidth(140);
        bar.setPrefHeight(7);

        // Difficulty chip
        Label diff = new Label(entry.diffLabel());
        diff.getStyleClass().add(switch (entry.weight()) {
            case 1  -> "chip-green";
            case 3  -> "chip-red";
            default -> "chip-yellow";
        });
        diff.setMinWidth(60);

        row.getChildren().addAll(codeLbl, nameLbl, bar, timeLbl, diff);
        return row;
    }

    private VBox buildRoadmapCard(ScheduleService.RoadmapEntry entry) {
        VBox card = new VBox(10);
        card.getStyleClass().add("roadmap-card");

        HBox header = new HBox(10);
        header.setAlignment(Pos.CENTER_LEFT);
        Label code = new Label(entry.code());
        code.getStyleClass().add("roadmap-code");
        Label name = new Label(entry.name());
        name.getStyleClass().add("roadmap-name");
        header.getChildren().addAll(code, name);

        FlowPane topics = new FlowPane(8, 6);
        for (String topic : entry.topics()) {
            Label chip = new Label(topic);
            chip.getStyleClass().add("chip-outline");
            topics.getChildren().add(chip);
        }

        card.getChildren().addAll(header, topics);
        return card;
    }

    private Label emptyLabel(String text) {
        Label l = new Label(text);
        l.getStyleClass().add("panel-subtitle");
        return l;
    }

    private Label panelTitle(String text) {
        Label l = new Label("▪  " + text);
        l.getStyleClass().add("panel-title");
        return l;
    }
}
