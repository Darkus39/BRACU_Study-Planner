package com.bracu.studyplanner.view.screens.tabs;

import com.bracu.studyplanner.model.CourseEntry;
import com.bracu.studyplanner.service.StudentService;
import com.bracu.studyplanner.view.components.StatusBadge;
import javafx.beans.binding.Bindings;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;

import java.util.Optional;

/**
 * Courses tab — full CRUD for the semester course plan.
 */
public class CoursesTab extends ScrollPane {

    public CoursesTab(StudentService service) {
        setFitToWidth(true);
        setFitToHeight(true);
        setHbarPolicy(ScrollBarPolicy.NEVER);
        getStyleClass().add("tab-scroll");

        VBox root = new VBox(24);
        root.getStyleClass().add("tab-root");
        root.setPadding(new Insets(36, 40, 36, 40));

        // ── Page header ───────────────────────────────────────────────────────
        Label title    = new Label("COURSE MANAGER");
        Label subtitle = new Label("Add · Remove · Plan your semester");
        title.getStyleClass().add("page-title");
        subtitle.getStyleClass().add("page-subtitle");

        // ── Add course panel ──────────────────────────────────────────────────
        VBox addPanel = new VBox(12);
        addPanel.getStyleClass().add("panel");

        Label addTitle = panelTitle("ADD COURSE");

        HBox addRow = new HBox(10);
        addRow.setAlignment(Pos.CENTER_LEFT);

        TextField codeInput = new TextField();
        codeInput.setPromptText("Course code  (e.g.  CSE221)");
        codeInput.getStyleClass().add("text-field");
        codeInput.setPrefWidth(280);
        HBox.setHgrow(codeInput, Priority.SOMETIMES);

        Button addBtn = new Button("ADD COURSE");
        addBtn.getStyleClass().add("btn-primary");

        StatusBadge addBadge = new StatusBadge();

        addRow.getChildren().addAll(codeInput, addBtn, addBadge);

        addBtn.setOnAction(e -> {
            String code = codeInput.getText().trim();
            if (code.isEmpty()) return;
            String err = service.addCourse(code);
            if (err != null) { addBadge.show("⚠  " + err); }
            else             { addBadge.hide(); codeInput.clear(); }
        });
        codeInput.setOnAction(e -> addBtn.fire());

        addPanel.getChildren().addAll(addTitle, addRow);

        // ── Course table ──────────────────────────────────────────────────────
        TableView<CourseEntry> table = buildTable(service);
        VBox.setVgrow(table, Priority.ALWAYS);
        table.setMinHeight(220);
        table.setPrefHeight(300);

        // ── Actions row ───────────────────────────────────────────────────────
        HBox actRow = new HBox(12);
        actRow.setAlignment(Pos.CENTER_LEFT);

        Button removeBtn = new Button("REMOVE SELECTED");
        removeBtn.getStyleClass().add("btn-danger");

        StatusBadge removeBadge = new StatusBadge();

        removeBtn.setOnAction(e -> {
            CourseEntry sel = table.getSelectionModel().getSelectedItem();
            if (sel == null) { removeBadge.show("⚠  Select a course to remove."); return; }
            String codeToRemove = sel.isLab() ? sel.getCode().replaceAll("L$", "") : sel.getCode();
            String err = service.removeCourse(codeToRemove);
            if (err != null) { removeBadge.show("⚠  " + err); }
            else             { removeBadge.hide(); }
        });

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label countChip = new Label();
        countChip.getStyleClass().add("chip-blue");
        countChip.textProperty().bind(Bindings.createStringBinding(() ->
            service.plannedCoursesProperty().filtered(c -> !c.isLab()).size() + " / 5 theory courses",
            service.plannedCoursesProperty()));

        Button finalizeBtn = new Button("FINALIZE SEMESTER  ⚑");
        finalizeBtn.getStyleClass().add("btn-secondary");
        finalizeBtn.setOnAction(e -> showFinalizeDialog(service));

        actRow.getChildren().addAll(removeBtn, removeBadge, spacer, countChip, finalizeBtn);

        // ── Study hours slider ────────────────────────────────────────────────
        VBox hoursPanel = new VBox(12);
        hoursPanel.getStyleClass().add("panel");

        Label hoursTitle = panelTitle("DAILY STUDY HOURS");

        HBox sliderRow = new HBox(16);
        sliderRow.setAlignment(Pos.CENTER_LEFT);

        Slider slider = new Slider(1, 12, service.studyHoursProperty().get());
        slider.setMajorTickUnit(1);
        slider.setMinorTickCount(0);
        slider.setSnapToTicks(true);
        slider.setShowTickMarks(true);
        slider.setShowTickLabels(true);
        HBox.setHgrow(slider, Priority.ALWAYS);

        Label hoursVal = new Label(String.format("%.0f hrs", service.studyHoursProperty().get()));
        hoursVal.getStyleClass().add("slider-value-label");
        hoursVal.setMinWidth(55);

        slider.valueProperty().addListener((o, ov, nv) -> {
            double h = Math.round(nv.doubleValue());
            hoursVal.setText((int) h + " hrs");
            service.updateStudyHours(h);
        });

        sliderRow.getChildren().addAll(slider, hoursVal);
        hoursPanel.getChildren().addAll(hoursTitle, sliderRow);

        root.getChildren().addAll(new VBox(4, title, subtitle), addPanel, table, actRow, hoursPanel);
        setContent(root);
    }

    // ── Table ─────────────────────────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    private TableView<CourseEntry> buildTable(StudentService service) {
        TableView<CourseEntry> table = new TableView<>();
        table.getStyleClass().add("data-table");
        table.setItems(service.plannedCoursesProperty());
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        table.setPlaceholder(new Label("No courses yet — use the field above to add courses."));

        // Code column
        TableColumn<CourseEntry, String> codeCol = new TableColumn<>("CODE");
        codeCol.setCellValueFactory(new PropertyValueFactory<>("code"));
        codeCol.setPrefWidth(110);
        codeCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setStyle(""); return; }
                setText(item);
                CourseEntry entry = getTableView().getItems().get(getIndex());
                setStyle(entry.isLab()
                    ? "-fx-text-fill: #4e5a70; -fx-font-style: italic;"
                    : "-fx-text-fill: #f59e0b; -fx-font-family: 'JetBrains Mono','Courier New',monospace; -fx-font-weight: bold;");
            }
        });

        // Name column
        TableColumn<CourseEntry, String> nameCol = new TableColumn<>("COURSE NAME");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        nameCol.setPrefWidth(320);

        // Credits
        TableColumn<CourseEntry, Integer> creditCol = new TableColumn<>("CR");
        creditCol.setCellValueFactory(new PropertyValueFactory<>("credits"));
        creditCol.setPrefWidth(55);
        creditCol.setStyle("-fx-alignment: CENTER;");

        // Difficulty stars
        TableColumn<CourseEntry, String> diffCol = new TableColumn<>("DIFFICULTY");
        diffCol.setPrefWidth(130);
        diffCol.setCellValueFactory(cell ->
            new javafx.beans.property.SimpleStringProperty(cell.getValue().getDifficultyStars()));
        diffCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); return; }
                setText(item);
                setStyle("Lab".equals(item)
                    ? "-fx-text-fill: #4e5a70; -fx-font-size: 11px;"
                    : "-fx-text-fill: #f59e0b; -fx-font-size: 14px;");
            }
        });

        // Type badge
        TableColumn<CourseEntry, String> typeCol = new TableColumn<>("TYPE");
        typeCol.setPrefWidth(85);
        typeCol.setCellValueFactory(cell ->
            new javafx.beans.property.SimpleStringProperty(cell.getValue().isLab() ? "LAB" : "THEORY"));
        typeCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); return; }
                setText(item);
                setStyle("LAB".equals(item)
                    ? "-fx-text-fill: #38bdf8; -fx-font-size: 11px; -fx-font-weight: bold;"
                    : "-fx-text-fill: #22c55e; -fx-font-size: 11px; -fx-font-weight: bold;");
            }
        });

        table.getColumns().addAll(codeCol, nameCol, creditCol, diffCol, typeCol);
        return table;
    }

    // ── Finalize dialog ───────────────────────────────────────────────────────

    private void showFinalizeDialog(StudentService service) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Finalize Semester");

        DialogPane pane = dialog.getDialogPane();
        pane.getStylesheets().add(getClass().getResource(
            "/com/bracu/studyplanner/css/app.css").toExternalForm());
        pane.getStyleClass().add("dialog-pane");

        ButtonType confirmType = new ButtonType("CONFIRM & FINALIZE", ButtonBar.ButtonData.OK_DONE);
        ButtonType cancelType  = new ButtonType("CANCEL",             ButtonBar.ButtonData.CANCEL_CLOSE);
        pane.getButtonTypes().addAll(confirmType, cancelType);

        VBox content = new VBox(16);
        content.setPadding(new Insets(24, 28, 12, 28));

        Label info = new Label(
            "Enter your GPA for this semester.\n" +
            "The system will calculate your updated cumulative CGPA automatically.");
        info.getStyleClass().add("dialog-info");
        info.setWrapText(true);
        info.setMaxWidth(360);

        int theoryCount = (int) service.plannedCoursesProperty().stream().filter(c -> !c.isLab()).count();
        Label theoryNote = new Label("Theory courses this semester: " + theoryCount);
        theoryNote.getStyleClass().add("dialog-note");

        Label gpaLbl = new Label("SEMESTER GPA (0.00 – 4.00)");
        gpaLbl.getStyleClass().add("field-label");
        TextField gpaInput = new TextField();
        gpaInput.setPromptText("e.g.  3.50");
        gpaInput.getStyleClass().add("text-field");

        Label warning = new Label(
            "⚠  This will clear all planned courses and advance to the next semester.");
        warning.getStyleClass().add("dialog-warning");
        warning.setWrapText(true);
        warning.setMaxWidth(360);

        content.getChildren().addAll(info, theoryNote, gpaLbl, gpaInput, warning);
        pane.setContent(content);

        dialog.setResultConverter(bt -> bt);
        Optional<ButtonType> result = dialog.showAndWait();
        result.ifPresent(bt -> {
            if (bt == confirmType) {
                String raw = gpaInput.getText().trim().replace(",", ".");
                double gpaVal;
                try { gpaVal = Double.parseDouble(raw); }
                catch (NumberFormatException ex) {
                    showError("Invalid input — please enter a valid GPA number.");
                    return;
                }
                String err = service.finalizeSemester(gpaVal);
                if (err != null) showError(err);
            }
        });
    }

    private void showError(String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR, msg, ButtonType.OK);
        a.setHeaderText("Error");
        a.getDialogPane().getStylesheets().add(
            getClass().getResource("/com/bracu/studyplanner/css/app.css").toExternalForm());
        a.showAndWait();
    }

    private Label panelTitle(String text) {
        Label l = new Label("▪  " + text);
        l.getStyleClass().add("panel-title");
        return l;
    }
}
