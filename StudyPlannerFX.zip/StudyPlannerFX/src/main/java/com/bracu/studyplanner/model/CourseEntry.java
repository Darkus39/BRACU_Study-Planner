package com.bracu.studyplanner.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Represents a single course (theory or lab) in a student's semester plan.
 * Used as row data in the JavaFX TableView.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CourseEntry {

    private String  code;
    private String  name;
    private int     credits;
    private int     difficultyWeight; // 1 = Easy, 2 = Medium, 3 = Hard
    private boolean lab;              // true = auto-added lab companion

    // ── Display helpers ──────────────────────────────────────────────────────

    /** Human-readable difficulty label for the UI. */
    public String getDifficultyLabel() {
        if (lab) return "Lab";
        return switch (difficultyWeight) {
            case 1  -> "Easy";
            case 2  -> "Medium";
            case 3  -> "Hard";
            default -> "—";
        };
    }

    /** Star-icon difficulty for the table column. */
    public String getDifficultyStars() {
        if (lab) return "Lab";
        return "★".repeat(difficultyWeight) + "☆".repeat(Math.max(0, 3 - difficultyWeight));
    }
}
