@echo off
REM ═══════════════════════════════════════════════════════════════════════════
REM  build-installer.bat — BRACU Study Planner Windows installer builder
REM
REM  Produces:
REM    Windows → StudyPlanner-2.0.0.exe  (NSIS setup wizard via jpackage)
REM              StudyPlanner-2.0.0.msi  (MSI installer via jpackage)
REM
REM  Requirements:
REM    - JDK 21+  (must include jpackage, bundled since JDK 14)
REM    - Maven 3.8+ on PATH
REM    - WiX Toolset 3.x on PATH (for .msi — https://wixtoolset.org)
REM      (for .exe only, WiX is not required)
REM
REM  Usage:
REM    Double-click  build-installer.bat
REM    OR run from command prompt:  build-installer.bat
REM ═══════════════════════════════════════════════════════════════════════════

setlocal enabledelayedexpansion

set APP_NAME=StudyPlanner
set APP_VERSION=2.0.0
set MAIN_CLASS=com.bracu.studyplanner.app.Launcher
set DESCRIPTION=BRACU Academic Management System
set VENDOR=BRACU Study Planner

set SCRIPT_DIR=%~dp0
set PROJECT_DIR=%SCRIPT_DIR%
set TARGET_DIR=%PROJECT_DIR%target
set INSTALLER_DIR=%PROJECT_DIR%installer-output

echo.
echo ===================================================
echo   BRACU Study Planner - Windows Installer Builder
echo ===================================================
echo.

REM ── Step 1: Build fat JAR ────────────────────────────────────────────────
echo [1/3] Building fat JAR with Maven...
cd /d "%PROJECT_DIR%"
call mvn clean package -q -DskipTests
if errorlevel 1 (
    echo ERROR: Maven build failed.
    pause
    exit /b 1
)
echo       Done: target\StudyPlannerFX-%APP_VERSION%.jar

REM ── Step 2: Check JAR exists ─────────────────────────────────────────────
set JAR_PATH=%TARGET_DIR%\StudyPlannerFX-%APP_VERSION%.jar
if not exist "%JAR_PATH%" (
    echo ERROR: JAR not found at %JAR_PATH%
    pause
    exit /b 1
)

REM ── Step 3: Create output directory ──────────────────────────────────────
if not exist "%INSTALLER_DIR%" mkdir "%INSTALLER_DIR%"

REM ── Step 4: Build .exe installer (no WiX required) ───────────────────────
echo.
echo [2/3] Building .exe installer with jpackage...

jpackage ^
    --input "%TARGET_DIR%" ^
    --name "%APP_NAME%" ^
    --main-jar "StudyPlannerFX-%APP_VERSION%.jar" ^
    --main-class "%MAIN_CLASS%" ^
    --app-version "%APP_VERSION%" ^
    --description "%DESCRIPTION%" ^
    --vendor "%VENDOR%" ^
    --dest "%INSTALLER_DIR%" ^
    --type exe ^
    --win-dir-chooser ^
    --win-menu ^
    --win-menu-group "BRACU" ^
    --win-shortcut ^
    --win-shortcut-prompt ^
    --java-options "-Dfile.encoding=UTF-8" ^
    --java-options "--add-opens=javafx.graphics/com.sun.javafx.application=ALL-UNNAMED"

if errorlevel 1 (
    echo WARNING: .exe build failed. Trying app-image fallback...
    jpackage ^
        --input "%TARGET_DIR%" ^
        --name "%APP_NAME%" ^
        --main-jar "StudyPlannerFX-%APP_VERSION%.jar" ^
        --main-class "%MAIN_CLASS%" ^
        --app-version "%APP_VERSION%" ^
        --dest "%INSTALLER_DIR%" ^
        --type app-image ^
        --java-options "-Dfile.encoding=UTF-8"
    echo       Portable app-image built. Run: installer-output\%APP_NAME%\%APP_NAME%.exe
    goto :done
)

echo       .exe installer built.

REM ── Step 5: Try .msi as well (requires WiX) ──────────────────────────────
where candle >nul 2>&1
if not errorlevel 1 (
    echo.
    echo       WiX found - also building .msi...
    jpackage ^
        --input "%TARGET_DIR%" ^
        --name "%APP_NAME%" ^
        --main-jar "StudyPlannerFX-%APP_VERSION%.jar" ^
        --main-class "%MAIN_CLASS%" ^
        --app-version "%APP_VERSION%" ^
        --vendor "%VENDOR%" ^
        --dest "%INSTALLER_DIR%" ^
        --type msi ^
        --win-dir-chooser ^
        --win-menu ^
        --win-menu-group "BRACU" ^
        --win-shortcut ^
        --java-options "-Dfile.encoding=UTF-8"
    echo       .msi installer built.
)

:done
echo.
echo [3/3] Done!
echo.
echo ===================================================
echo   Output: %INSTALLER_DIR%
echo.
echo   To install:
echo     .exe  - Double-click the setup wizard
echo     .msi  - Double-click or deploy via Group Policy
echo.
echo   The installer bundles its own JRE.
echo   No Java installation needed on target machines.
echo ===================================================
echo.
pause
